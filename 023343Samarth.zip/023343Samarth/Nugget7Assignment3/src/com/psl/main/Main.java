package com.psl.main;

import com.psl.app.WordCount;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		WordCount wc = new WordCount();
		String sen = "my my my name";
		String wor = "my";
		int cnt = wc.check(sen, wor);
		System.out.println(cnt);
	}

}
