package com.psl.app;

public class WordCount {

	public int check(String sentence,String word){
		int count = 0;
		String[] sent = sentence.split(" ");
		for(String string:sent){
			if(string.equalsIgnoreCase(word)){
				count++;
			}
		}
		return count;
	}
}
