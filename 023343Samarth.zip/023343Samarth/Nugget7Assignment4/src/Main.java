
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String sent = "To be or not to be";
		Reverse rev = new Reverse();
		String reversedWord = rev.reverseWordByWord(sent);
		System.out.println(reversedWord);
	}

}
