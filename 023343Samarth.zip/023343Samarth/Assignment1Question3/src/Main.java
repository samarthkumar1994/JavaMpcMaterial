import java.util.Scanner;


public class Main {

	public static int[] findPrime(int first, int last){
		int prime[] = new int[10];
		int k,l=0;
		for(int i =first; i<last;i++){
			k=0;
			for(int j =1;j<=i;j++){
				if(i%j==0)
					k++;
			}
			if(k==2)
				prime[l++]=i;
		}
		return prime;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		int first = sc.nextInt();
		int last = sc.nextInt();
		int primeNos[] = findPrime(first,last);
		for(int value:primeNos){
			System.out.println(value);
		}
	}

}
