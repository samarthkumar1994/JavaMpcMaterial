package com.psl.beans;

import java.util.Date;

//extends implies is-a relation
public class Employee extends Person{
	//member variables
	private int id;
	private String name;
	private double salary;
	private Date joinDate;
	private String gender;
	private double grade;
	//private String title;
	private Address address;			//implies composition has-a relationship 

	//Getters and Setters
	/*public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}*/

	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}

	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}
	public Date getJoinDate() {
		return joinDate;
	}
	public void setJoinDate(Date joinDate) {
		this.joinDate = joinDate;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		if(this.gender.equals("Male")){
			setTitle("Mr. ");
		}
		else{
			setTitle("Ms. ");
		}

	}
	public double getGrade() {
		return grade;
	}
	public void setGrade(double grade) {
		this.grade = grade;
	}

	//Constructor
	public Employee() {
		super();
	}

	public Employee(int id, String name, double salary, Date joinDate,
			String gender, double grade) {
		super();
		this.id = id;
		this.name = name;
		this.salary = salary;
		this.joinDate = joinDate;
		this.gender = gender;
		this.grade = grade;
	}
	@Override
	public String toString() {
		return "Employee [id=" + id + ", name=" + name + ", salary=" + salary
				+ ", joinDate=" + joinDate + ", gender=" + gender + ", grade="
				+ grade + "]";
	}
	public double calculateBonus(){
		double bonus=0;
		if(grade < 3.3){
			bonus = salary * 0.1;
		}
		else{
			bonus = salary * 0.12;
		}
		return bonus;
	}
}
