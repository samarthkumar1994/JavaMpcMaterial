package com.psl.beans;

public class Address {

	private String city;
	private String landmark;
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getLandmark() {
		return landmark;
	}
	public void setLandmark(String landmark) {
		this.landmark = landmark;
	}
	public Address(String city, String landmark) {
		super();
		this.city = city;
		this.landmark = landmark;
	}
	public Address() {
		super();
		// TODO Auto-generated constructor stub
	}
	
}
