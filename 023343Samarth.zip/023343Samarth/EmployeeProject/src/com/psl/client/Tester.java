package com.psl.client;

import java.util.Date;

import com.psl.beans.Address;
import com.psl.beans.Employee;

public class Tester {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Employee emp = new Employee(1,"sam",25000.0,new Date(),"Male",3.0);
		emp.setGender("Male");
		System.out.println(emp);
		double bonus = emp.calculateBonus();
		System.out.println("bonus amount for the employee is: "+ bonus);
		System.out.println(emp.getTitle());
		emp.setAddress(new Address());
		emp.getAddress().setCity("Pune");
		System.out.println(emp.getAddress().getCity());
	}

}
