package com.psl.util;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.psl.beans.Movies;
import com.psl.comparators.DirectorComparator;
import com.psl.comparators.DurationComparator;
import com.psl.comparators.LanguageComparator;
import com.psl.comparators.SortByLanguageAndReleaseDateComparator;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<Movies> movieList = new ArrayList<>();
		movieList = getAllMovies();
		/*
		for(Movies mov:movieList){
		 System.out.println(mov);
		}
		*/
		Collections.sort(movieList,new DirectorComparator());
		System.out.println("---After director comparator---");
		for(Movies mov:movieList){
			 System.out.println(mov);
			}
		
		sortByLanguage(movieList);
		
		SortByLanguageAndReleaseDate(movieList);
		
		sortByDuration(movieList);

	}

	static List<Movies> getAllMovies(){
		
		List<Movies> movieList = new ArrayList<>();
		Movies m1 = new Movies("Pulp fiction", "Irish", "21-1-2016", "Pandey ji", "Khan sahab", 50);
		Movies m2 = new Movies("Dabangg","Hindi","16-12-2015","Shukla ji","Khan sahab",48);
		Movies m3 = new Movies("ABCD","Hindi","25-05-2015","Sharma ji","Chang sahab",78);
		
		movieList.add(m1);
		movieList.add(m2);
		movieList.add(m3);
		
		return movieList;
	}
	
	static void sortByLanguage(List<Movies> movieList){
		
		Collections.sort(movieList);
		System.out.println("-----After language comparable-----");
		for (Movies movies : movieList) {
			System.out.println(movies);
		}
	}
	
	public static void SortByLanguageAndReleaseDate(List<Movies> movieList){
		
		Collections.sort(movieList, new SortByLanguageAndReleaseDateComparator());
		System.out.println("-----After SortByLanguageAndReleaseDate------");
		for (Movies movies : movieList) {
			System.out.println(movies);
		}
	}
	
	public static void sortByDuration(List<Movies> movieList){
		Collections.sort(movieList,new DurationComparator());
		System.out.println("-----After Duration comparision");
		for (Movies movies : movieList) {
			System.out.println(movies);
		}
	}
}
