package com.psl.comparators;

import java.util.Comparator;

import com.psl.beans.Movies;

public class DurationComparator implements Comparator<Movies>{

	@Override
	public int compare(Movies o1, Movies o2) {
		// TODO Auto-generated method stub
		int i = o1.getDuration() - o2.getDuration();
		
		return i;
	}

}
