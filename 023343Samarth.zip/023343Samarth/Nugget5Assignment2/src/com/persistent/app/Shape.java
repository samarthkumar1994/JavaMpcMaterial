package com.persistent.app;

public interface Shape {
	
	public void calcArea();
	public void calcPeri();
	public void display();

}
