package com.persistent.app;

public class Square implements Shape{

	float side;
	float area;
	float peri;
	
	public Square(float s) {
		// TODO Auto-generated constructor stub
		this.side = s;
	}
	
	@Override
	public void calcArea() {
		// TODO Auto-generated method stub
		this.area = (side * this.side);
		
	}

	@Override
	public void calcPeri() {
		// TODO Auto-generated method stub
		this.peri = 4 * side;
		
	}

	@Override
	public void display() {
		// TODO Auto-generated method stub
		calcArea();
		calcPeri();
		System.out.println("Area: " + this.area + " perimeter: " + peri);
	}

}
