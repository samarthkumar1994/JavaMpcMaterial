package com.persistent.app;

public class Rectangle implements Shape{

	float len;
	float bre;
	float area;
	float peri;
	
	public Rectangle(float l, float b) {
		// TODO Auto-generated constructor stub
		this.len = l;
		this.bre = b;
	}

	@Override
	public void calcArea() {
		// TODO Auto-generated method stub
		this.area = len * bre;
	}

	@Override
	public void calcPeri() {
		// TODO Auto-generated method stub
		this.peri = 2 * (len + bre);
	}

	@Override
	public void display() {
		// TODO Auto-generated method stub
		calcArea();
		calcPeri();
		System.out.println("Area of rectangle: " + area + " perimeter: "+peri);
	}
	
	
}
