package com.persistent.util;

import com.persistent.app.Rectangle;
import com.persistent.app.Square;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Square s = new Square(5f);
		s.display();
		Rectangle r = new Rectangle(5f, 2f);
		r.display();
	}

}
