package com.psl.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeSet;

import com.psl.beans.Employee;

public class Main {

	public static void main(String[] args){
		
		Employee e1 = new Employee(1,"samarth",(java.util.Date)java.sql.Date.valueOf("1994-05-25"));
		Employee e2 = new Employee(2,"suraj",(java.util.Date)java.sql.Date.valueOf("1994-06-25"));
		Employee e3 = new Employee(3,"neeraj",(java.util.Date)java.sql.Date.valueOf("1994-08-19"));
		
		Set<Employee> set = new TreeSet<Employee>();
		set.add(e1);
		set.add(e2);
		set.add(e3);
		//Display all info
		System.out.println(set);
		
		//all employees who have joined organization before entered date.
		Scanner sc = new Scanner(System.in);
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		String date = sc.next();
		Date d1;
		try {
			d1 = sdf.parse(date);
			for(Employee e : set){
				if(e.getJoinDate().before(d1)==true)
					System.out.println(e);
			}
		} catch (ParseException e4) {
			// TODO Auto-generated catch block
			e4.printStackTrace();
		}
		
		//Display all employees who have completed six month in organization.
		
		Calendar startCalendar = new GregorianCalendar();
		Calendar endCalendar = new GregorianCalendar();
		
		for(Employee e : set){
			startCalendar.setTime(new Date());
			endCalendar.setTime(e.getJoinDate());
			int diffYear = endCalendar.get(Calendar.YEAR) - startCalendar.get(Calendar.YEAR);
			int diffMonth = diffYear * 12 + endCalendar.get(Calendar.MONTH) - startCalendar.get(Calendar.MONTH);
			if(Math.abs(diffMonth) >= 6){
				System.out.println(e);
			}
		}
	}
}
