package com.psl.beans;

import java.util.Date;

public class Employee implements Comparable<Employee>{

	int empId;
	String name;
	Date joinDate;
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Date getJoinDate() {
		return joinDate;
	}
	public void setJoinDate(Date joinDate) {
		this.joinDate = joinDate;
	}
	public Employee(int empId, String name, Date joinDate) {
		super();
		this.empId = empId;
		this.name = name;
		this.joinDate = joinDate;
	}
	
	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", name=" + name + ", joinDate="
				+ joinDate + "]";
	}
	@Override
	public int compareTo(Employee arg0) {
		int i = this.getEmpId() - arg0.getEmpId();
	
		return i;
	}
	
}
