package com.psl.beans;

public class Syrup extends Medicine{

	@Override
	public void displayLabel(){
		System.out.println("twice a day");
	} 
}
