package com.psl.beans;

public class Ointment extends Medicine {
	@Override
	public void displayLabel(){
		System.out.println("for external use only");
	}
}
