package com.psl.beans;

public class Medicine {
	
	public Medicine(){
		
	}
	
	public void displayLabel(){
		
	}
}
