package com.psl.beans;

public class Company {

	private String name;
	private String location;
	private Medicine[] med;			//1 company many medicines
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public Medicine[] getMed() {
		return med;
	}

	public void setMed(Medicine[] med) {
		this.med = med;
	}

}
