package com.psl.util;

import java.util.Random;

import com.psl.beans.Company;
import com.psl.beans.Medicine;
import com.psl.beans.Ointment;
import com.psl.beans.Syrup;
import com.psl.beans.Tablet;

public class TestMedicine {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Company comp = new Company();
		comp.setName("SUn pharma");
		comp.setLocation("Pune");
		Medicine[] medArray = new Medicine[10];
		Random rn = new Random();
		for(int i=0; i<10; i++){
			
			    int answer = rn.nextInt(3);
			   // System.out.println(answer);
			    if(answer%3==0){
					medArray[i] = new Tablet();
				}
				else if(answer%3 ==1){
					medArray[i] = new Syrup();
				}
				else if(answer%3==2){
					medArray[i] = new Ointment();
				}
			
		}
		comp.setMed(medArray);
		
		for(Medicine medicine : comp.getMed()){
			medicine.displayLabel();
		}
	}

}
