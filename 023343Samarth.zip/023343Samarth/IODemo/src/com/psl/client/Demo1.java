package com.psl.client;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class Demo1 {

	public static void main(String[] args){
		File file = new File("C:\\Users\\Administrator\\Desktop\\abc.txt");
		createFile(file);
		readFile(file);
		File source = new File("C:\\Users\\Public\\Videos\\Sample Videos");
		File destination = new File("copyof"+ source.getName());
		copyFile(source,destination);
	}
	
	static void copyFile(File source, File destination){
		FileInputStream fin = null;
		FileOutputStream fout = null;
		try {
			fin = new FileInputStream(source);
			fout = new FileOutputStream(destination);
			
			byte[] data = new byte[1000];
			while(fin.read(data)!=-1){
				fout.write(data);
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally{
			try {
				fin.close();
				fout.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		
	}
	
	static void readFile(File file){
		int data = 0;
		try(FileReader fr = new FileReader(file)){
			while((data = fr.read())!=-1){
				System.out.print((char)data);
			}
		} catch(IOException e){
			e.printStackTrace();
		}
	}
	
	static void createFile(File file){
		try(FileWriter fw = new FileWriter(file)){
			fw.write("Thsi is added");
		}
		catch(IOException e){
			e.printStackTrace();
		}
	}
}
