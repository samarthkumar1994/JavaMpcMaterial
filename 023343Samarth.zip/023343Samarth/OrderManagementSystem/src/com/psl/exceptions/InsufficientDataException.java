package com.psl.exceptions;

public class InsufficientDataException extends Exception{

}
