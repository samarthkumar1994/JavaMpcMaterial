package com.psl.client;

import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import com.psl.beans.Customer;
import com.psl.beans.OrderItem;
import com.psl.beans.StockItem;
import com.psl.dao.ConnectionManager;
import com.psl.dao.CustomerManagerDb;
import com.psl.dao.DBConnenctionManager;
import com.psl.dao.PurchaseOrderManagerDB;
import com.psl.dao.StockItemManagerDB;
import com.psl.utility.PurchaseOrderManager;

public class Client {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		PurchaseOrderManager p = new PurchaseOrderManager();
		
		List<Customer> cList = new ArrayList<>();
		cList = p.populateCustomers();
		//System.out.println(cList);
		
		List<StockItem> sList = new ArrayList<StockItem>();
		sList = p.populateStoreItems();
		System.out.println(sList);
		
		StockItemManagerDB sdb = new StockItemManagerDB();
		sdb.insertStockItems(sList);
		
		PurchaseOrderManagerDB pdb = new PurchaseOrderManagerDB();
		/*for (Customer cust : cList) {
			Random rand = new Random();
			int  orderNo = rand.nextInt(50) + 1;
			boolean val = pdb.insertcustomerOrder(cust.getId(),orderNo);

		}
		
		List<OrderItem> oList = new ArrayList<OrderItem>();
		OrderItem o1 = new OrderItem("coca cola", 2);
		OrderItem o2 = new OrderItem("oneplus3",1);
		oList.add(o1);
		oList.add(o2);
		p.createOrder(1, oList, java.sql.Date.valueOf("2017-02-28"));*/
	}

}
