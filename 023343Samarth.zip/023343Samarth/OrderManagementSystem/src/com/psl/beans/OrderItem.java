package com.psl.beans;

public class OrderItem {

	String stockItemName;
	int qty;
	
	public OrderItem(String stockItemName, int qty) {
		super();
		this.stockItemName = stockItemName;
		this.qty = qty;
	}
	public String getStockItemName() {
		return stockItemName;
	}
	public void setStockItemName(String stockItemName) {
		this.stockItemName = stockItemName;
	}
	public int getQty() {
		return qty;
	}
	public void setQty(int qty) {
		this.qty = qty;
	}
	
}
