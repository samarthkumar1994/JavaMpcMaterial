package com.psl.beans;

import java.sql.Date;

public class StockItem {
	int id;
	String name;
	String description;
	Enum unit;
	double pricePerUnit;
	Date mfg_date;
	Date best_before_dt;
	
//101,coca cola,cold drink,GALLONS,10.0,2017-01-01,2017-06-01

	public StockItem(int id, String name, String description, Enum unit,
			double pricePerUnit, Date mfg_date, Date best_before_dt) {
		super();
		this.id = id;
		this.name = name;
		this.description = description;
		this.unit = unit;
		this.pricePerUnit = pricePerUnit;
		this.mfg_date = mfg_date;
		this.best_before_dt = best_before_dt;
	}
	@Override
	public String toString() {
		return "StockItem [id=" + id + ", name=" + name + ", description="
				+ description + ", unit=" + unit + ", pricePerUnit="
				+ pricePerUnit + ", mfg_date=" + mfg_date + ", best_before_dt="
				+ best_before_dt + "]"+"\n";
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public Enum getUnit() {
		return unit;
	}
	public void setUnit(Enum unit) {
		this.unit = unit;
	}
	public double getPricePerUnit() {
		return pricePerUnit;
	}
	public void setPricePerUnit(double pricePerUnit) {
		this.pricePerUnit = pricePerUnit;
	}
	public Date getMfg_date() {
		return mfg_date;
	}
	public void setMfg_date(Date mfg_date) {
		this.mfg_date = mfg_date;
	}
	public Date getBest_before_dt() {
		return best_before_dt;
	}
	public void setBest_before_dt(Date best_before_dt) {
		this.best_before_dt = best_before_dt;
	}
	
	
}
