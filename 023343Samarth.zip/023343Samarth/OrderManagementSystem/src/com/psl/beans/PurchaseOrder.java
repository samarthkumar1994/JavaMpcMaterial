package com.psl.beans;

import java.io.Serializable;
import java.sql.Date;
import java.util.List;

public class PurchaseOrder implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	int orderno;
	Date orderdate;
	Date shipdate;
	List<OrderItem> orderedItemslist;
	public PurchaseOrder(int orderno, Date orderdate, Date shipdate) {
		super();
		this.orderno = orderno;
		this.orderdate = orderdate;
		this.shipdate = shipdate;
	}
	public int getOrderno() {
		return orderno;
	}
	public void setOrderno(int orderno) {
		this.orderno = orderno;
	}
	public Date getOrderdate() {
		return orderdate;
	}
	public void setOrderdate(Date orderdate) {
		this.orderdate = orderdate;
	}
	public Date getShipdate() {
		return shipdate;
	}
	public void setShipdate(Date shipdate) {
		this.shipdate = shipdate;
	}
	public List<OrderItem> getOrderedItemslist() {
		return orderedItemslist;
	}
	public void setOrderedItemslist(List<OrderItem> orderedItemslist) {
		this.orderedItemslist = orderedItemslist;
	}
	
	

}
