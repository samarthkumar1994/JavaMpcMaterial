package com.psl.beans;

public enum Units {
	KG, GALLONS, GRAMS, NOS;
}
