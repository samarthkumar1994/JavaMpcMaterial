package com.psl.utility;

import java.io.File;
import java.io.FileNotFoundException;
import java.sql.Date;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

import com.psl.beans.Customer;
import com.psl.beans.OrderItem;
import com.psl.beans.PurchaseOrder;
import com.psl.beans.StockItem;
import com.psl.beans.Units;

public class PurchaseOrderManager {

	public List<Customer> populateCustomers(){
		List<Customer> cList = new ArrayList<Customer>();
		Scanner sc =  null;
		try {
			sc = new Scanner(new File("customer.txt"));
			while(sc.hasNext()){
				String[] data = sc.nextLine().split(",");
				Customer c = new Customer(Integer.parseInt(data[0].trim()), data[1].trim(), data[2].trim(), data[3].trim(),data[4].trim(),data[5].trim(), data[6].trim());
				cList.add(c);
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally{
			sc.close();
		}
		return cList;
	}
	
	public List<StockItem> populateStoreItems (){
		List<StockItem> sList = new ArrayList<StockItem>();
		Scanner sc = null;
		try {
			sc = new Scanner(new File("item.txt"));
			while(sc.hasNext()){
				String[] data = sc.nextLine().split(",");
				StockItem s;
				try {

					//101,coca cola,cold drink,GALLONS,10.0,2017-01-01,2017-06-01
					System.out.println(data[4] + " " + data[5]);
					s = new StockItem(Integer.parseInt(data[0].trim()), data[1].trim(), data[2].trim(), Units.valueOf(data[3].trim()), Double.parseDouble(data[4].trim()),java.sql.Date.valueOf(data[5]),java.sql.Date.valueOf(data[6]));
					sList.add(s);
				} catch (NumberFormatException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
			}
		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		return sList;
	}
	
	public void createOrder(int cust_id,List<OrderItem> oList,Date ship_date){
		
	}
	
	public void storePurchaseOrder(){
		
	}
	
	public void shipOrders(){
		
	}
	
	public void removeExpiredItems(){
		
	}
	
	public void showItems(){
		
	}
	
	public void applyDiscountOnItems(){
		
	}
	
	public Map<Customer,List<PurchaseOrder>> getOrdersByCustomer(){
		
		return null;
	}
	
	void displayDiscountedItemsList(){
		
	}
}
