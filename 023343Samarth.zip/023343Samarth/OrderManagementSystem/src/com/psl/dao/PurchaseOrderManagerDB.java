package com.psl.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import com.psl.beans.OrderItem;
import com.psl.beans.PurchaseOrder;

public class PurchaseOrderManagerDB {

	public boolean insertOrderItem(List<OrderItem> oList){
		boolean flag = false;
		/*ConnectionManager cm = new DBConnenctionManager();
		Connection conn = cm.getDBConnection("jdbc:mysql://localhost:3307/orderDB", "root", "root");
		PreparedStatement pstmt=null;
		for (OrderItem orderItem : oList) {
			pstmt = conn.prepareStatement("INSERT INTO order_item ");
		}*/
		
		return flag;
	}
	
	boolean insertPurchaseOrder(PurchaseOrder p){
		
		return false;
	}
	
	public boolean insertcustomerOrder(int customerID,int orderID){
		ConnectionManager cm = new DBConnenctionManager();
		Connection conn = cm.getDBConnection("jdbc:mysql://localhost:3307/orderDB", "root", "root");
		PreparedStatement pstmt=null;
		boolean flag=false;
		try {
			pstmt = conn.prepareStatement("INSERT INTO customer_order_details values(?,?)");
			pstmt.setInt(1, customerID);
			pstmt.setInt(2,orderID);
			int i = pstmt.executeUpdate();
			
			if(i!=0)
				flag = true;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return flag;
	}
	
	public List<PurchaseOrder> getAllOrdersByCustomer(int cust_id){
		
		return null;
	}
	
	List<PurchaseOrder> ordersToBeShipped(Date fromdate, Date todate){
		
		return null;
	}
	
	public void deletePurchaseOrder(int orderno){
		
	}
	
	public void deleteOrderItem(int orderno){
		
	}
	
	public void insertShippedOrders(int cust_no, List<PurchaseOrder> pList,List<OrderItem> oList,String PersonName){
		
	}
	
	
}
