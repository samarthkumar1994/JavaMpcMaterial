package com.psl.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import com.psl.beans.StockItem;
import com.psl.beans.Units;

public class StockItemManagerDB {
	public void insertStockItems(List<StockItem> stockItemlist){
		//101,coca cola,cold drink,GALLONS,10.0,2017/01/01,2017/06/01
		ConnectionManager cm = new DBConnenctionManager();
		Connection conn = cm.getDBConnection("jdbc:mysql://localhost:3307/orderDB", "root", "root");
		PreparedStatement pstmt=null;
		try {
			pstmt = conn.prepareStatement("INSERT INTO stock_item values(?,?,?,?,?,?,?)");
			for(StockItem s : stockItemlist){
				pstmt.setInt(1, s.getId());
				pstmt.setString(2, s.getName());
				pstmt.setString(3, s.getDescription());
				pstmt.setString(4, s.getUnit().toString());
				pstmt.setDouble(5, s.getPricePerUnit());
				pstmt.setDate(6, (Date) s.getMfg_date());
				pstmt.setDate(7, (Date) s.getBest_before_dt());
				
				pstmt.executeUpdate();
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public List<StockItem> getStockItems(){
		
		return null;
	}
	
	public void deleteStockItems(int no){
		
	}
}
