package com.psl.dao;

import java.sql.Connection;

public interface ConnectionManager {
	public Connection getDBConnection(String url,String user,String pwd);
	public void closeConnection(Connection conn) ;

}
