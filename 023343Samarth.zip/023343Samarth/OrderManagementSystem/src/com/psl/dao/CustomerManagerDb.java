package com.psl.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import com.psl.beans.Customer;

public class CustomerManagerDb {

	public void insertCustomers(List<Customer>customers){
		//Inserts Customers details into database
		//		Customer (id,name,address,email, purchaseOrderList)
		ConnectionManager cm = new DBConnenctionManager();
		Connection conn = cm.getDBConnection("jdbc:mysql://localhost:3307/orderDB", "root", "root");
		PreparedStatement pstmt=null;
		for (Customer customer : customers) {
			try {
			
				pstmt = conn.prepareStatement("INSERT INTO customer_details values(?,?,?,?)");
				pstmt.setInt(1, customer.getId());
				pstmt.setString(2, customer.getName());
				//String address = customer.getAddress().getCity() +" " + customer.getAddress().getState()+" "+customer.getAddress().getZip();
				//pstmt.setString(3, customer.getAddress());
				pstmt.setString(4, customer.getEmail());
				pstmt.executeUpdate();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}	
		}
		
	}
}
