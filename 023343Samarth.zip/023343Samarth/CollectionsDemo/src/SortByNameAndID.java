import java.util.Comparator;


public class SortByNameAndID implements Comparator<Student>{

	@Override
	public int compare(Student st1, Student st2) {
		// TODO Auto-generated method stub
		int i = st1.getRollNo() - st2.getRollNo();
		if(i==0)
			i=st1.getName().compareTo(st2.getName());
		
		return i;
	}

}
