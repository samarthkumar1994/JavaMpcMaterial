import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.ListIterator;
import java.util.Set;
import java.util.TreeSet;

class SortByNameId implements Comparator<Employee>{
	
	@Override
	public int compare(Employee e1, Employee e2) {
		// TODO Auto-generated method stub
		int i = e1.getEmpName().compareTo(e2.getEmpName());
		
		if(i==0){					//if the names are equal
			i=e1.getEmpID() - e2.getEmpID();
		}
		return i;
	}
}

class Employee implements Comparable<Employee>{
	int empID;
	String empName;
	String city;
	public int getEmpID() {
		return empID;
	}
	public void setEmpID(int empID) {
		this.empID = empID;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	@Override
	public String toString() {
		return "Employee [empID=" + empID + ", empName=" + empName + ", city="
				+ city + "]";
	}
	public Employee(int empID, String empName, String city) {
		super();
		this.empID = empID;
		this.empName = empName;
		this.city = city;
	}
	@Override
	public int compareTo(Employee o) {
		// TODO Auto-generated method stub
		if(this.empID < o.getEmpID())
			return -1;
		
		return 0;
	}

}

public class CollectionsTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//testLists();
		
		//testSets();
		List<Employee> empList = getEmployees();
		
		for(Employee emp: empList){
			System.out.println(emp);
		}
		
		Set<Employee> empSet = new HashSet<>();
		empSet.addAll(empList);
		System.out.println(empSet.size());
		
		System.out.println("------Sort by ID -------");
		for(Employee employee:empSet){
			System.out.println(employee);
		}
		
		Set<Employee> empSetByName = new TreeSet<Employee>(new SortByNameId());
		empSetByName.addAll(empSet);
		System.out.println("-------Sort by name------");
		for(Employee employee:empSetByName){
			System.out.println(employee);
		}
		
		class SortByCity implements Comparator<Employee>{
			@Override
			public int compare(Employee e1, Employee e2) {
				// TODO Auto-generated method stub
				int i = e1.getCity().compareTo(e2.getCity());
				if(i==0){
					i=e1.getEmpID()-e2.getEmpID();
				}
				return i;
			}
		}
		
		Set<Employee> empSetByCity = new TreeSet<>(new SortByCity());
		empSetByCity.addAll(empSet);
		System.out.println("-------Sort by city------");
		for(Employee employee:empSetByCity){
			System.out.println(employee);
		}
	}
	
	static List<Employee> getEmployees(){
		Employee e1 = new Employee(100,"sam","pune");
		Employee e2 = new Employee(200,"suraj","Bangalore");
		Employee e3 = new Employee(300,"jack","Agra");
		Employee e4 = e1;
		Employee e5 = new Employee(400,"sam","Agra");
		
		List<Employee> empList = new ArrayList<>();
		empList.add(e1);
		empList.add(e2);
		empList.add(e3);
		empList.add(e4);
		empList.add(e5);
		
		return empList;
	}
	
	static void testLists(){
		ArrayList<String> list = new ArrayList();
		list.add("20");
		list.add("Hello");
		list.add("34.7");
		list.add("Test");
		list.add("true");
		
	//	System.out.println(Collections.binarySearch(list, "20"));
		
		//iterate using a for each loop
		System.out.println("iterate using a for each loop");
		
		for(Object obj:list){
			if(obj instanceof String){
			System.out.println(((String) obj).toUpperCase());
			}
			else
				System.out.println(obj);
		}
		
		//iterate using iterator
		System.out.println("iterate using iterator");
		Iterator itr = list.iterator();
		while(itr.hasNext()){
			Object obj = itr.next();
			System.out.println(obj);
		}
		
		System.out.println("Size of list......" + list.size());
		
		//index based retrieval
		System.out.println("index based retrieval");
		for(int i=0; i<list.size();i++){
			System.out.println(list.get(i));
		}
		
		//list iterator
		/*System.out.println("Inside list iterator.....\n");
		ListIterator lit = list.listIterator();
		while(lit.hasPrevious()){
			System.out.println(lit.next());
		}*/
	}
	
	static void testSets(){
		Set set = new LinkedHashSet<String>();
		
		set.add("Apple");
		set.add("Aaaa");
		
		Set s = new TreeSet<String>();
		s.add("Hello");
		s.add("Bellow");
		System.out.println(set.containsAll(s));
		
		//iterator is good when we want to iterate and modify elements
	}

}
