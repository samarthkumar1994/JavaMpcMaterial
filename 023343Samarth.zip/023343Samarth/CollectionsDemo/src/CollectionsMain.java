import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;


public class CollectionsMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<Student> studList = null;
		studList = getStudentList();
		for (Student student : studList) {
			System.out.println(student);
		}
		
		Set<Student> studSet = new TreeSet<Student>(new SortByNameAndID());
		studSet.addAll(studList);
		System.out.println("----------SET IMPLEMENTATION----------");
		for (Student student : studSet) {
			System.out.println(student);
		}
	}
	
	static List<Student> getStudentList(){
		List<Student> studList = new ArrayList<>();
		Student s1 = new Student(1,"sam");
		Student s2 = new Student(2,"abc");
		Student s3 = new Student(1,"zia");
		Student s4 = new Student(3,"def");
		studList.add(s1);
		studList.add(s2);
		studList.add(s3);
		studList.add(s4);
		return studList;
	}

}
