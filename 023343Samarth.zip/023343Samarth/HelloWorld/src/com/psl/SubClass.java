package com.psl;
import java.util.*;
public class SubClass {
public static void main(String args[]) {
TreeMap<String, Integer> treeMap = new TreeMap();
treeMap.put("A", 10);
treeMap.put("B", 20);
treeMap.put("C", 30);
System.out.println(treeMap.entrySet());
}
}