package com.psl;

public class SuperClass {
static{
System.out.println("Static block 1 of super class");
}
static{
System.out.println("Static block 2 of super class");
}
{
System.out.println("Instance block 1 of super class");
}
{
System.out.println("Instance block 2 of super class");
}
public SuperClass() {
System.out.println("Constructor of super class");
}
}