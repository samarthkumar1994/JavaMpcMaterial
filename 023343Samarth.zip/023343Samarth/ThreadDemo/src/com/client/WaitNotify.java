package com.client;

class Account{
	private int balance;
	
	public int getBalance() {
		return balance;
	}
	public void setBalance(int balance) {
		this.balance = balance;
	}
	void deposit(int amt){
		balance +=amt;
	}
	void withdraw(int amt){
		balance -=amt;
	}
}

class Depositor implements Runnable{
	Account account = null;
	
	public Depositor(Account acc) {
		this.account = acc;
	}
	@Override
	public void run() {
		System.out.println(Thread.currentThread().getName() + " Entered in bank");
		account.deposit(1000);
		synchronized (account) {
			
			account.notify();
			System.out.println(" now balance is " + account.getBalance());
		}

	}
	
}

class Withdrawer implements Runnable{
	Account acc = null;
	public Withdrawer(Account acc) {
		// TODO Auto-generated constructor stub
		this.acc = acc;
	}
	
	@Override
	public void run() {
		// TODO Auto-generated method stub
		System.out.println(Thread.currentThread().getName() + " Entered in bank");
		synchronized (acc) {
			try {
				acc.wait();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			acc.withdraw(1000);
			System.out.println("After withdraw= "+acc.getBalance());
		}

	}
	
}

public class WaitNotify {

	public static void main(String[] args) {
		Account acc = new Account();
		Depositor dep = new Depositor(acc);
		Withdrawer wit = new Withdrawer(acc);
		
		Thread t1 = new Thread(dep,"Depositer");
		Thread t2 = new Thread(wit,"Withdrawer");
		
		t2.start();
		t1.start();
	}

}
