package com.client;

class ChildThread implements Runnable{

	@Override
	public void run() {
		for(int i =0 ;i<10; i++){
			System.out.println(i);
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
}

class MyThread extends Thread{
	public void run(){
		for(int i = 0; i< 10; i++){
			System.out.println("i8*i="+i*i);
			try {
				Thread.sleep(2000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
}

public class ThreadTest {

	public static void main(String[] args) {
		System.out.println(Thread.currentThread().getName());
		System.out.println(Thread.currentThread().getPriority());
		System.out.println(Thread.currentThread().isAlive());
		System.out.println(Thread.currentThread().isDaemon());
		
		MyThread thread = new MyThread();		//this line specifies that the thread is born
		thread.setName("MyThread1");
		thread.setPriority(Thread.MAX_PRIORITY);
		thread.setDaemon(true);
		thread.start();							//initiates a thread to go to runnable state
		
		ChildThread t1 = new ChildThread();
		Thread thread2 = new Thread(t1);
		thread2.setName("runnable thread");
		thread2.start();
		System.out.println("-----End of main----");
	}

}
