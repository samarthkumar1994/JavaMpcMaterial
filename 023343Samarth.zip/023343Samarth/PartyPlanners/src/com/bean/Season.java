package com.bean;

import com.enums.SeasonCode;

public class Season {
private SeasonCode seasonType;
private Duration duration;
/**
 * @return the duration
 */
public Duration getDuration() {
	return duration;
}
/**
 * @param duration the duration to set
 */
public void setDuration(Duration duration) {
	this.duration = duration;
}
/**
 * @return the seasonType
 */
public SeasonCode getSeasonType() {
	return seasonType;
}
/**
 * @param seasonType the seasonType to set
 */
public void setSeasonType(SeasonCode seasonType) {
	this.seasonType = seasonType;
}
@Override
public String toString() {
	return "Season [seasonType=" + seasonType + ", duration=" + duration + "]"+"\n";
}
public Season(SeasonCode seasonType, Duration duration) {
	super();
	this.seasonType = seasonType;
	this.duration = duration;
}


}
