package com.bean;

import java.io.Serializable;
import java.nio.channels.Pipe.SinkChannel;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.enums.CateringType;
import com.enums.PartyType;

public class Party implements Serializable,Comparable<Party> {
	
private static final long serialVersionUID =-2033454618949883819L;
private int partyId;
private PartyType partyType;
private Date partyDate;
private int noOfPersons;
private String venue;
private CateringType cateringType;
private boolean decoration;
private boolean equipment;
private boolean music;
private boolean video;
private boolean photography;
private long cost;
/*public Party(int i, PartyType youngAdults, String string, CateringType cateringType,Date parse, int j,
		boolean b, boolean c, boolean d, boolean e, boolean f, boolean g) {
	// TODO Auto-generated constructor stub
	partyId=i;
	partyType=youngAdults;
	venue=string;
	this.cateringType=cateringType;
	partyDate=parse;
	noOfPersons=j;
	decoration=b;
	equipment=c;
	music=d;
	video=e;
	photography=g;
	
}*/


public Party() {
	// TODO Auto-generated constructor stub
}
public Party(int partyId, PartyType partyType, Date partyDate, int noOfPersons,
		String venue, CateringType cateringType, boolean decoration,
		boolean equipment, boolean music, boolean video, boolean photography,
		long cost) {
	super();
	this.partyId = partyId;
	this.partyType = partyType;
	this.partyDate = partyDate;
	this.noOfPersons = noOfPersons;
	this.venue = venue;
	this.cateringType = cateringType;
	this.decoration = decoration;
	this.equipment = equipment;
	this.music = music;
	this.video = video;
	this.photography = photography;
	this.cost = cost;
}
public int getPartyId() {
	return partyId;
}
public void setPartyId(int partyId) {
	this.partyId = partyId;
}
public PartyType getPartyType() {
	return partyType;
}
public void setPartyType(PartyType partyType) {
	this.partyType = partyType;
}
public Date getPartyDate() {
	return partyDate;
}
public void setPartyDate(Date partyDate) {
	this.partyDate = partyDate;
}
public int getNoOfPersons() {
	return noOfPersons;
}
public long getCost() {
	return cost;
}
public void setCost(long cost) {
	this.cost= cost;
}
public void setNoOfPersons(int noOfPersons) {
	this.noOfPersons = noOfPersons;
}
public String getVenue() {
	return venue;
}
public void setVenue(String venue) {
	this.venue = venue;
}
public CateringType getCateringType() {
	return cateringType;
}
public void setCateringType(CateringType cateringType) {
	this.cateringType = cateringType;
}
public boolean isDecoration() {
	return decoration;
}
public void setDecoration(boolean decoration) {
	this.decoration = decoration;
}
public boolean isEquipment() {
	return equipment;
}
public void setEquipment(boolean equipment) {
	this.equipment = equipment;
}
public boolean isMusic() {
	return music;
}
public void setMusic(boolean music) {
	this.music = music;
}
public boolean isVideo() {
	return video;
}
public void setVideo(boolean video) {
	this.video = video;
}
public boolean isPhotography() {
	return photography;
}
public void setPhotography(boolean photography) {
	this.photography = photography;
}
@Override
public String toString() {
	SimpleDateFormat sdf=new SimpleDateFormat("dd-MM-yyyy");
	String s=sdf.format(partyDate);
	return "Party [partyId=" + partyId + ", partyType=" + partyType
			+ ", partyDate=" + partyDate + ", noOfPersons=" + noOfPersons
			+ ", venue=" + venue + ", cateringType=" + cateringType
			+ ", decoration=" + decoration + ", equipment=" + equipment
			+ ", music=" + music + ", video=" + video + ", photography="
			+ photography + ", cost=" + cost + "]" +"\n";
}
@Override
public int compareTo(Party o) {
	// TODO Auto-generated method stub
	return (int) (this.getCost() - o.getCost());
}

}
