package com.client;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.bean.Party;
import com.bean.Season;
import com.enums.PartyType;
import com.enums.SeasonCode;
import com.util.PartyPlanner;
import com.util.PartyPlannerImpl;

public class Client {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		PartyPlanner p = new PartyPlannerImpl();
		
		Set<Party> partySet = new HashSet<>();
		partySet = p.takePartyName("Party.ser");
		//System.out.println(partySet);
		
		Set<Season> season = new HashSet<Season>();
		season = p.populateSeason("SeasonDuration.txt");
		
		
		SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
		/*
		try {
			Date d = sdf.parse("05-09-2016");
			SeasonCode s = p.getSeason(season, d);
			System.out.println(s);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
		
		/*Set<Party> planned = new HashSet<Party>();
		Date toDate = null;
		Date fromDate = null;
		try {
			toDate = sdf.parse("08-08-2016");
			fromDate = sdf.parse("05-05-2016");
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		planned = p.plannedParty(partySet, toDate , fromDate);
		//System.out.println(planned);
		
		try {
			toDate = sdf.parse("05-03-2016");
			List<String> nm = new ArrayList<String>();

			nm = p.notificationMessage(partySet, toDate);
			System.out.println(partySet);
			System.out.println(nm);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		*/
		Map<PartyType, Party> map = new HashMap<PartyType, Party>();
		map=p.highestPartyEarninCategory(partySet);
		System.out.println(map);

	}

}
