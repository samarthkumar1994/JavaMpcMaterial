package com.enums;

public enum SeasonCode {
SUMMER(0),AUTUMN(10),SPRING(15),WINTER(20);
private int discount;
private SeasonCode(int discount) {
	// TODO Auto-generated constructor stub
	this.setDiscount(discount);
}
public int getDiscount() {
	return discount;
}
public void setDiscount(int discount) {
	this.discount = discount;
}

}
