package com.enums;

public enum PartyType {
YOUNG_ADULTS,KIDS,FAMILY;
}
