package com.enums;

public enum CateringType {
BUFFET(100),SERVICE(100);

int val;

private CateringType(int val) {
	// TODO Auto-generated constructor stub
	this.val = val;
	
}

public int getVal() {
	return val;
}

public void setVal(int val) {
	this.val = val;
}

}
