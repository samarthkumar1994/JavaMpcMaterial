package com.exception;

public class NoPartyFoundException extends Throwable {
public NoPartyFoundException() throws Exception
{
	throw new Exception();
}
}
