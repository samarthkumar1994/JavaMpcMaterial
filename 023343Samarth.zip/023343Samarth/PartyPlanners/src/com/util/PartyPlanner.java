package com.util;

import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.bean.Party;
import com.bean.Season;
import com.enums.PartyType;
import com.enums.SeasonCode;

public interface PartyPlanner {
Set<Party> takePartyName(String fileName);
Set<Season> populateSeason(String FileName);
SeasonCode getSeason(Set<Season> season,Date date);
Set<Party> plannedParty(Set<Party> party,Date toDate,Date fromDate );
List<String> notificationMessage(Set<Party> party,Date date);
long calculateCost(Party party);
Map<PartyType, Party> highestPartyEarninCategory(Set<Party> party);

}
