package com.util;
import com.bean.Duration;
import com.bean.Party;
import com.bean.Season;
import com.enums.*;

import java.io.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeSet;

public class PartyPlannerImpl implements PartyPlanner {

	
	public Set<Party> takePartyName(String fileName) 
	{
		Set<Party> partySet = new HashSet<Party>();
		ObjectInputStream ois = null;;
		try {
			ois = new ObjectInputStream(new FileInputStream(new File(fileName)));
			while(true){
				Party p = (Party)ois.readObject();
				partySet.add(p);
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally{
			try {
				ois.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return partySet;
	}

	public Set<Season> populateSeason(String FileName) 
	{
		// SUMMER;1-3-2016:1-4-2016

		Set<Season> seasonSet = new HashSet<Season>();
		Scanner sc ;
		SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
		try {
			sc = new Scanner(new File(FileName));
			while(sc.hasNext()){
				String[] season = sc.nextLine().split(";");
				String[] durations = season[1].split(":");
				//System.out.println(season[0]);
				//System.out.println(durations[0] + " " + durations[1]);
				Duration d = new Duration(sdf.parse(durations[0]), sdf.parse(durations[1]));
				Season s = new Season(SeasonCode.valueOf(season[0]), d);
				seasonSet.add(s);
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return seasonSet;
	}

	
	public SeasonCode getSeason(Set<Season> season, Date date) 
	{
		// TODO Auto-generated method stub
		for(Season s : season){
			Duration d = s.getDuration();
			Date startDate = d.getFromDate();
			Date toDate = d.getToDate();
			if(date.after(startDate) && date.before(toDate)){
				return s.getSeasonType();
			}
		}
		
		return null;
	}

	
	public Set<Party> plannedParty(Set<Party> party, Date toDate, Date fromDate) 
	{
		// TODO Auto-generated method stub
		Set<Party> planned = new HashSet<Party>();
		
		for (Party p : party) {
			if (p.getPartyDate().after(fromDate) && p.getPartyDate().before(toDate)){
				planned.add(p);
			}
			else if(p.getPartyDate().equals(fromDate) || p.getPartyDate().equals(toDate)){
				planned.add(p);
			}
		}
		
		return planned;
	}


	public List<String> notificationMessage(Set<Party> party, Date date) {
		// TODO Auto-generated method stub
		List<String> nm = new ArrayList<String>();
		Calendar cal = Calendar.getInstance();
		Calendar cal1 = cal;
		cal.setTime(date);
		cal1.add(cal.DAY_OF_YEAR, 10);

		for (Party p : party) {
			if(p.getPartyDate().after(date) && p.getPartyDate().before(cal1.getTime())){
				String str = p.getPartyId() +" "+ p.getVenue() + " " + p.getPartyType() + " "+ p.getNoOfPersons() +"\n";
				nm.add(str);
			}
		}
		
		return nm;
	}


	public long calculateCost(Party party) 
	{
		// TODO Auto-generated method stub
		if(party.getCateringType().equals(CateringType.BUFFET)){
			party.setCost(party.getCateringType().getVal());
		}
		return 0;
	}

	public Map<PartyType, Party> highestPartyEarninCategory(Set<Party> party) {
		// TODO Auto-generated method stub
		List<Party> youngAdultList = new ArrayList<Party>();
		List<Party> kidsList = new ArrayList<Party>();
		List<Party> familyList = new ArrayList<Party>();
		
		Map<PartyType,Party> returnMap = new HashMap<PartyType, Party>();
		
		for (Party p : party) {
			if(p.getPartyType().equals(PartyType.YOUNG_ADULTS))
				youngAdultList.add(p);
			else if(p.getPartyType().equals(PartyType.KIDS))
				kidsList.add(p);
			else
				familyList.add(p);
		}
		
		Collections.sort(youngAdultList,new Comparator<Party>() {

			@Override
			public int compare(Party arg0, Party arg1) {
				// TODO Auto-generated method stub
				return (int) (arg0.getCost()-arg1.getCost());
			}
		});
		
		Collections.sort(kidsList,new Comparator<Party>() {

			@Override
			public int compare(Party arg0, Party arg1) {
				// TODO Auto-generated method stub
				return (int) (arg0.getCost()-arg1.getCost());
			}
		});
		
		Collections.sort(familyList,new Comparator<Party>() {

			@Override
			public int compare(Party arg0, Party arg1) {
				// TODO Auto-generated method stub
				return (int) (arg0.getCost()-arg1.getCost());
			}
		});
		
		   Collections.sort(youngAdultList, Collections.reverseOrder());
		   Collections.sort(kidsList, Collections.reverseOrder());
		   Collections.sort(familyList, Collections.reverseOrder());
		   
		   System.out.println(youngAdultList);
		  // System.out.println(kidsList);
		   
		   returnMap.put(PartyType.YOUNG_ADULTS, youngAdultList.get(1));
		   returnMap.put(PartyType.KIDS, kidsList.get(1));
		   returnMap.put(PartyType.FAMILY, familyList.get(1));

		return returnMap;
	}

	
	
}
