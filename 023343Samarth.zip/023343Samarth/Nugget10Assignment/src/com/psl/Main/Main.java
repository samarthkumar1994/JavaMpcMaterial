package com.psl.Main;

import java.sql.Connection;

import com.psl.util.DBConnection;

public class Main {

	public static void main(String[] args) {
		DBConnection db = new DBConnection();
		Connection conn = db.getConnection();
	}

}
