package com.psl.beans;

import java.sql.Date;
import java.util.ArrayList;

public class Employee {
	int empNo;
	String eName;
	Date joinDate;
	ArrayList<Address> address;
	public int getEmpNo() {
		return empNo;
	}
	public void setEmpNo(int empNo) {
		this.empNo = empNo;
	}
	public String geteName() {
		return eName;
	}
	public void seteName(String eName) {
		this.eName = eName;
	}
	public Date getJoinDate() {
		return joinDate;
	}
	public void setJoinDate(Date joinDate) {
		this.joinDate = joinDate;
	}
	public ArrayList<Address> getAddress() {
		return address;
	}
	public void setAddress(ArrayList<Address> address) {
		this.address = address;
	}
	public Employee(int empNo, String eName, Date joinDate,
			ArrayList<Address> address) {
		super();
		this.empNo = empNo;
		this.eName = eName;
		this.joinDate = joinDate;
		this.address = address;
	}
	
}
