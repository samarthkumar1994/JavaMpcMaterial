
public class Main {

	public static void main(String args[]) {
		permuteString("", "123");
	}

	public static void permuteString(String beginningString, String endingString) {
		if (endingString.length() <= 1)
			System.out.println(beginningString + endingString);
		else
			for (int i = 0; i < endingString.length(); i++) {
				String s1 = endingString.substring(0, i);
				String s2 = endingString.substring(i + 1);
				try {
					String newString = s1 + s2;

					permuteString(beginningString + endingString.charAt(i), newString);
				} catch (StringIndexOutOfBoundsException exception) {
					exception.printStackTrace();
				}
			}
	}
}

