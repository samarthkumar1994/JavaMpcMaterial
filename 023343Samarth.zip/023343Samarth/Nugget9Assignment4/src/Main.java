import java.util.HashSet;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeMap;


public class Main {

	static Map<String, Integer> maps = new TreeMap<String, Integer>();
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		countChars("samarth");
		countChars("samarth");
		countChars("suraj");
	}
	
	static void countChars(String str){
		for (Entry<String, Integer> e : maps.entrySet()) {
			if(e.getKey().equals(str)){
				System.out.println("Entry was already present");
				System.out.println("Unique chars: " + e.getValue());
			}
		}
		
		char[] ch =str.toCharArray();
		Set set = new HashSet();
		for(int i =0; i<ch.length;i++){
			set.add(ch[i]);
		}
		maps.put(str, set.size());
		System.out.println(maps);
	}

}
