package com.psl.beans;

import java.util.Date;

public class Employee {
	private int empID;
	private String empName;
	private String city;
	private Date joinDate;
	public Employee(int empID, String empName, String city, Date joinDate) {
		super();
		this.empID = empID;
		this.empName = empName;
		this.city = city;
		this.joinDate = joinDate;
	}
	public int getEmpID() {
		return empID;
	}
	public void setEmpID(int empID) {
		this.empID = empID;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public Date getJoinDate() {
		return joinDate;
	}
	public void setJoinDate(Date joinDate) {
		this.joinDate = joinDate;
	}
	
	
}
