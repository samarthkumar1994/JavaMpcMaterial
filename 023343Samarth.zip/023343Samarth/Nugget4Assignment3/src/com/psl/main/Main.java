package com.psl.main;

import java.io.IOException;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeMap;

import com.psl.beans.*;
public class Main {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		Map<String,String> maps = new TreeMap<String, String>();
		CityStateMap c = new CityStateMap();
		maps = c.initializeMap("CityStateList");
		System.out.println(maps);
		/*String state = maps.get("Jamnagar");
		System.out.println(state);
		
		//Get all cities
		Set<String> citySet = null;
		citySet = c.getAllCities(maps);
		for (String string : citySet) {
			System.out.println(string);
		}
		*/
		//Get cities for a state
		Scanner sc = new Scanner(System.in);
		/*System.out.println("Enter a state: ");
		String str = sc.next();
		for(Entry<String, String> e : maps.entrySet()){
			int i = str.compareTo(e.getValue());
			if(i==0)
				System.out.println("City: "+e.getKey());
		}
		*/
		//Add a new city state pair
		
		//Removing this is causing concurrentmodification exception
		/*maps.put("Sangli","Maharashtra");
		System.out.println(maps);
		*/
		
		
		
		//Delete all the cities for a given state
		System.out.println("ENter a state to delete the cities:" );
		String str1 = sc.next();
		for(Entry<String, String> e : maps.entrySet()){
			int i = e.getValue().compareTo(str1);
			if(i==0){
				maps.entrySet().remove(e);
			}
		}
		System.out.println(maps);
		
		maps.put("Sangli","Maharashtra");
		System.out.println(maps);
		
	}

}
