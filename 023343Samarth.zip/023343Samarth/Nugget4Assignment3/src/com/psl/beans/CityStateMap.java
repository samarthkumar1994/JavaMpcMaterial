package com.psl.beans;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;
import java.util.TreeMap;

public class CityStateMap {

	String City;
	String State;

	String[] citystate;
	
	public Map<String,String> initializeMap(String fileName) throws IOException{
		Map<String,String> maps = new TreeMap<String,String>();
		File f = new File(fileName);
		Scanner sc = new Scanner(f);
		while(sc.hasNext()){
			citystate = sc.nextLine().split(","); 
			maps.put(citystate[0],citystate[1]);
		}
		return maps;
	}
	
	public Set<String> getAllCities(Map<String,String> maps){
		Set<String> cityList = null;
		cityList = maps.keySet();
		return cityList;
	}
	
	
		
}
