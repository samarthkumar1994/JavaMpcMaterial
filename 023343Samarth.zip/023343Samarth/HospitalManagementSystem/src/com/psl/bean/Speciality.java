package com.psl.bean;

public enum Speciality{
Pediatric,Oncologist,Garnacologist,Radiologist,Dermatologist
}
