package com.psl.bean;

import java.io.Serializable;
import java.util.Set;

public class Hospital implements Serializable {

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + hospitalId;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Hospital other = (Hospital) obj;
		if (hospitalId != other.hospitalId)
			return false;
		return true;
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = 1320852801512120278L;
	private int hospitalId;
	private int bedCount;
	private Set<Doctor> set ;
	private String hospitalName;

	
	
	
	

	@Override
	public String toString() {
		return "Hospital [hospitalId=" + hospitalId + ", bedCount=" + bedCount
				+ ", set=" + set + ", hospitalName=" + hospitalName + "]" +"\n";
	}

	public int getHospitalId() {
		return hospitalId;
	}

	public void setHospitalId(int hospitalId) {
		this.hospitalId = hospitalId;
	}

	public int getBedCount() {
		return bedCount;
	}

	public void setBedCount(int bedCount) {
		this.bedCount = bedCount;
	}

	public Set<Doctor> getSet() {
		return set;
	}

	public void setSet(Set<Doctor> set) {
		this.set = set;
	}

	public String getHospitalName() {
		return hospitalName;
	}

	public void setHospitalName(String hospitalName) {
		this.hospitalName = hospitalName;
	}

}
