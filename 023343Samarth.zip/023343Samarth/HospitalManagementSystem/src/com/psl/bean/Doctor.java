package com.psl.bean;

import java.io.Serializable;
import java.sql.Date;

public class Doctor implements Serializable, Comparable<Doctor> {

	
	private static final long serialVersionUID = 2700192949117685712L;
	private int doctorId;
	private String doctorName;
	private int hospitalId;
	private Date joiningDate;
	private Speciality speciality;
	private int experience;

	
	
	
	
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Doctor other = (Doctor) obj;
		if (doctorId != other.doctorId)
			return false;
		return true;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + doctorId;
		return result;
	}

	@Override
	public String toString() {
		return "Doctor [doctorId=" + doctorId + ", doctorName=" + doctorName
				+ ", hospitalId=" + hospitalId + ", joiningDate=" + joiningDate
				+ ", speciality=" + speciality + ", experience=" + experience
				+ "]";
	}

	public int getDoctorId() {
		return doctorId;
	}

	public void setDoctorId(int doctorId) {
		this.doctorId = doctorId;
	}

	public String getDoctorName() {
		return doctorName;
	}

	public void setDoctorName(String doctorName) {
		this.doctorName = doctorName;
	}

	public int getHospitalId() {
		return hospitalId;
	}

	public void setHospitalId(int hospitalId) {
		this.hospitalId = hospitalId;
	}

	public Date getJoiningDate() {
		return joiningDate;
	}

	public void setJoiningDate(Date joiningDate) {
		this.joiningDate = joiningDate;
	}

	public Speciality getSpeciality() {
		return speciality;
	}

	public void setSpeciality(Speciality speciality) {
		this.speciality = speciality;
	}

	public void setExperience(int experience) {
		this.experience = experience;
	}

	public int getExperience() {
		return experience;
	}

	@Override
	public int compareTo(Doctor arg0) {
		// TODO Auto-generated method stub
		
		return this.doctorId - arg0.getDoctorId();
	}

}
