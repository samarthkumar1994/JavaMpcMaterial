package com.psl.main;

import java.util.Set;
import java.util.TreeSet;

import com.psl.bean.Doctor;
import com.psl.bean.Hospital;
import com.psl.util.HospitalInformationSystem;
import com.psl.util.impll;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HospitalInformationSystem h = new impll();
		Set<Hospital> hSet = new TreeSet<Hospital>();
		hSet = h.readAllHospital("hospital.ser", "doctor.ser");
		//System.out.println(hSet);
		
		Set<Doctor> dSet = new TreeSet<Doctor>();
		dSet = h.getListOfDoctors(hSet);
		System.out.println(dSet);
	}

}
