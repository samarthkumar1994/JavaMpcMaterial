package com.psl.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.sql.Date;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Comparator;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import com.psl.bean.Doctor;
import com.psl.bean.Hospital;
import com.psl.bean.Speciality;

public class impll implements HospitalInformationSystem{

	@Override
	public Set<Hospital> readAllHospital(String fileHospital, String fileDoctor) {
		// TODO Auto-generated method stub
		Set<Hospital> hSet = new TreeSet<>(new Comparator<Hospital>(){

			@Override
			public int compare(Hospital arg0, Hospital arg1) {
				// TODO Auto-generated method stub
				return arg0.getHospitalId()-arg1.getHospitalId();
			}
		});
		List<Doctor> dList = new ArrayList<Doctor>();
		ObjectInputStream oin = null;
		ObjectInputStream oin1 = null;
	
		try {
			oin = new ObjectInputStream(new FileInputStream(new File(fileHospital)));
			while(true){
				Hospital h = (Hospital)oin.readObject();
				if(h!=null)
					hSet.add(h);
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally{
			try {
				oin.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		try {
			oin1=new ObjectInputStream(new FileInputStream(new File(fileDoctor)));
			while(true){
				Doctor d = (Doctor)oin1.readObject();
				if(d!=null)
					dList.add(d);
			}
		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			//e1.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		Set<Doctor> d = null;
		for (Hospital hosp : hSet) {
			for(Doctor doc : dList){
				if(hosp.getHospitalId() == doc.getHospitalId()){
					 d  = new TreeSet<Doctor>();
						d.add(doc);
				}
			}
			hosp.setSet(d);
		}
		
		
		return hSet;
	}

	@Override
	public Set<Doctor> getListOfDoctors(Set<Hospital> treeSet) {
		// TODO Auto-generated method stub
	//	System.out.println(treeSet);
		Set<Doctor> docSet = new TreeSet<Doctor>();
		for(Hospital hos : treeSet){
			Set<Doctor> innerSet = new TreeSet<Doctor>();
			innerSet = hos.getSet();
			for(Doctor d : innerSet){
				long today = Calendar.getInstance().getTimeInMillis();
				long jDate = d.getJoiningDate().getTime();
				int time = (int)((today-jDate)/(1000*60*60*24));
				d.setExperience(time);
				if(time >= 1000){
					docSet.add(d);
				}
			}
			
		}
		return docSet;
	}

	@Override
	public List<Doctor> eligibleForAppointment(Set<Hospital> treeSet,
			Speciality speciality, int experienceInDays) {
		// TODO Auto-generated method stub
		List<Doctor> dList = new ArrayList<Doctor>();
		for (Hospital hospital : treeSet) {
			Set<Doctor> innerSet = new TreeSet<Doctor>();
			innerSet = hospital.getSet();
			for(Doctor d : innerSet){
				if((d.getSpeciality().equals(speciality)) && (d.getExperience()>experienceInDays)){
					dList.add(d);
					break;
				}
			}
		}
		return dList;
	}

	@Override
	public List<Doctor> getListWithinHospital(Set<Hospital> treeSet,
			int hospitalId, Speciality speciality, int experience) {
		// TODO Auto-generated method stub
		return null;
	}

}
