package com.psl.Client;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;


public class MapTest {

	public static void main(String[] args){
		testMaps();
	}
	
	static void testMaps(){
		Map<String,Integer> maps = new TreeMap<String, Integer>();
		//hashmap allows only one null key and multiple null values
		maps.put("One",1);
		maps.put("Two", 2);
		maps.put("Three",3);
		
		Set<String> set = maps.keySet();
		for(String string:maps.keySet()){
			System.out.println("key: "+string+"\tValue: "+maps.get(string));
		}
		
		for(Map.Entry<String, Integer> m: maps.entrySet()){
			System.out.println(m.getKey()+"\t"+m.getValue());
		}
		
		System.out.println(maps.containsKey("Two"));
		System.out.println(maps.containsValue(2));
	}
}
