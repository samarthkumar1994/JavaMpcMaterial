package com.psl.client;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class JDBCTest {
	
	 

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//1.Loading the driver
		try {
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("Loaded the driver......");
			
		//2. define the connection URL -> protocol with server and port, username, password
			String url = "jdbc:mysql://localhost:3307/employeedb";
			String username = "root";
			String pswd = "root";
			
		//3. Create connection	
			Connection conn = DriverManager.getConnection(url,username,pswd);
			System.out.println("Connected...."+conn);
		
		//4.Create statement	
			Statement stmt = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
			//stmt.executeUpdate("insert into employee values(3,'suraj','sangli','404048','2017-01-23'); ");
			String query = "select * from employee";
			
		//5. Execute query	
			
			ResultSet rs = stmt.executeQuery(query);
			PreparedStatement pstmt = conn.prepareStatement("select * from employee where empID=?");
			pstmt.setInt(1, 1);
			ResultSet rs1 = pstmt.executeQuery();
			while(rs1.next()){
				System.out.println(rs1.getInt(1) + "\t"+ rs1.getString("empName") + "\t"+ rs1.getString(3)+ "\t" + rs1.getString(4) + "\t" + rs1.getDate(5) );
			}
			
		//6. process result	
			while(rs.next()){
				System.out.println(rs.getInt(1) + "\t"+ rs.getString("empName") + "\t"+ rs.getString(3)+ "\t" + rs.getString(4) + "\t" + rs.getDate(5) );
			}
			rs.absolute(1);
			rs.updateString(2, "Jack");
			rs.updateRow();
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
