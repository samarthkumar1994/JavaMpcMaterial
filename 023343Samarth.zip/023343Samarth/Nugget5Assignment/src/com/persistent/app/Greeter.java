package com.persistent.app;

public class Greeter {
	String name;

	public Greeter(String aName) {
		this.name = aName;
	}

	public void sayHello(){
		System.out.println("Hello " + name);

	}

	public void sayBye(){
		System.out.println("Bye " + name);

	}
}
