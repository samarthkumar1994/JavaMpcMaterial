package com.persistent.app;

import java.util.Random;

public class Advisor {

	String[] message;
	
	public Advisor() {
		// TODO Auto-generated constructor stub
	message = new String[5];
	message[0] = "Never say never again";
	message[1] = "Die another day";
	message[2] = "From russia with love";
	message[3] = "Take advice always";
	message[4] = "Do what your heart says";
	}
	
	public void getAdvice(){
		Random rn = new Random();
		int answer = rn.nextInt(4);
		System.out.println(message[answer]);
	}
}
