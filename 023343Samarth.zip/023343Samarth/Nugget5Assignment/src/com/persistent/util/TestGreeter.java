package com.persistent.util;

import com.persistent.app.Advisor;
import com.persistent.app.Greeter;

public class TestGreeter {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Greeter[] g = new Greeter[10];
		for(int i = 0; i < args.length; i++){
			g[i] = new Greeter(args[i]);
		}
		
		for(int i =0; i<args.length; i++){
			g[i].sayHello();
		}
		
		Advisor ad = new Advisor();
		ad.getAdvice();
		
		for(int i = args.length-1; i >= 0; i--){
			g[i].sayBye();
		}
	}

}
