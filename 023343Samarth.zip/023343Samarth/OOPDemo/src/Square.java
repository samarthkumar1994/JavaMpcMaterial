
public class Square extends Shape{

	@Override
	public void print() {
		// TODO Auto-generated method stub
		System.out.println("square");
	}

	@Override
	public void move() {
		// TODO Auto-generated method stub
		System.out.println("square moving");
	}

	@Override
	public void bounce() {
		// TODO Auto-generated method stub
		
	}

}
