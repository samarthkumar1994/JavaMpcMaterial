
public class GameCanvas {

	public void drawShape(Shape s){
		s.print();
	}
	
	public void animateShape(Shape s){
		s.move();
	}
}
