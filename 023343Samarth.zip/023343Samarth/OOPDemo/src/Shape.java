
public abstract class Shape {
	public abstract void print();
	public abstract void move();

	public abstract void bounce();

}
