
public class TestShapes {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		GameCanvas can = new GameCanvas();
		Triangle triangle = new Triangle();
		can.drawShape(triangle);
		can.animateShape(triangle);
		
	}

}
