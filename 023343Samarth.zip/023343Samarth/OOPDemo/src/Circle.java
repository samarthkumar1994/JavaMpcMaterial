
public class Circle extends Shape{

	@Override
	public void print() {
		// TODO Auto-generated method stub
		System.out.println("cicrle");
	}

	@Override
	public void move() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void bounce() {
		// TODO Auto-generated method stub
		System.out.println("cicrcle jumping");
	}

}
