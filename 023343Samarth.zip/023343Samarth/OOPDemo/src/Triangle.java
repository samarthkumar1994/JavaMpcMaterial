
public class Triangle extends Shape{

	@Override
	public void print() {
System.out.println("triangle");		
	}

	@Override
	public void move() {
		// TODO Auto-generated method stub
		System.out.println("triangle is moving");
	}

	@Override
	public void bounce() {
		// TODO Auto-generated method stub
		
	}

}
