package com.beans;

import com.psl.exceptions.InvalidInputException;

public class Calculator {
	
	public int add(int x, int y){
		return x+y;
	}
	
	public int multiplication(int x, int y){
		int result = x* y;
		return result;
	}
	
	public float divide(int x, int y) throws InvalidInputException{
		float result = 0;
		if(y==0){
				result = x/y;
				throw new InvalidInputException("Custome xpection");
			
		}
		 
		return result;
	}

}
