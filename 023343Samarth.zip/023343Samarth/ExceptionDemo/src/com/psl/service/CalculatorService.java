package com.psl.service;

import com.beans.Calculator;
import com.psl.exceptions.InvalidInputException;

public class CalculatorService {

	public float calculate(int x, int y, int operation) throws Exception, InvalidInputException{
		Calculator cal = new Calculator();
		float res = 0;
		switch (operation) {
		case 1:
			res = cal.add(x, y);
			break;
		case 2:
			res = cal.multiplication(x, y);
			break;
		case 3:
			res = cal.divide(x, y);
		default:
			break;
		}
		return res; 
	}
}
