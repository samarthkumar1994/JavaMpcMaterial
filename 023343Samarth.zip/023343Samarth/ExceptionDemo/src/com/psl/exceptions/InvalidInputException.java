package com.psl.exceptions;

public class InvalidInputException extends Throwable{

		public InvalidInputException(String m) {
			// TODO Auto-generated constructor stub
			System.out.println(m);
		}
}
