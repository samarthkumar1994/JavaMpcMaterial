package com.psl.client;

import com.psl.exceptions.InvalidInputException;
import com.psl.service.CalculatorService;

public class Client {

	public static void main(String[] args) throws InvalidInputException{
		try{
		int x = 10, y = 0;
		float result = 0;
		CalculatorService ser = new CalculatorService();
		result = ser.calculate(x, y, 1);
		System.out.println(result);
		
		result = ser.calculate(x, y, 2);
		System.out.println(result);
		
		result = ser.calculate(x, y, 3);
		System.out.println(result);
		}
		catch(Exception e){
			System.out.println(e.getMessage());
		}
		System.out.println("End of main");
	}	
}
