package com.client;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

interface Message{
	
	void message(String... str);
}

class Person{
	String name;
	String age;
	int id;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAge() {
		return age;
	}
	public void setAge(String age) {
		this.age = age;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public Person(String name, String age, int id) {
		super();
		this.name = name;
		this.age = age;
		this.id = id;
	}
	
	
	@Override
	public String toString() {
		return "Person [name=" + name + ", age=" + age + ", id=" + id + "]";
	}
	public Person() {
		// TODO Auto-generated constructor stub
	}
	
	public int sortById(Person p1, Person p2){

		return p1.getId() - p2.getId();
	}
	
	public int sortByName(Person p1, Person p2){
		int i = p1.getName().compareTo(p2.getName());
		if(i==0)
			i = p1.getId() - p2.getId();
		return i;
	}
	
	public int sortByAge(Person p1, Person p2){
		
		return  p1.getId() - p2.getId();
	}
	
}
public class Demo {

	public static void main(String[] args){
		//legacy way
		
		/*Message msg = new Message() {
			
			@Override
			public void message() {
				// TODO Auto-generated method stub
				System.out.println("welcome to java 8");
			}
		};*/
		
		Message msg = (String... str) -> {for(String string : str){System.out.println(string);}};
		msg.message("ram","hyam");
		Person p = new Person();
		System.out.println("persons by id");
		Demo demo=new Demo();
		List<Person> personList = demo.getPersons();
		//Collections.sort(personList, p::sortByAge);
		
		Comparator<Person> comparator = (Person p1, Person p2) -> {
			int i = p2.getName().compareTo(p1.getName());
			if(i==0){
				i = p2.getId() - p1.getId();
			}
			return i;
		};
		
		Collections.sort(personList,comparator);
		demo.printPersons(personList);

		/*Set<Person> persons = new TreeSet<>(p::sortByName);
		persons.addAll(demo.getPersons());*/
	}
	
	void printPersons(Collection<Person> coll){
		for(Person person:coll){
			System.out.println(person);
		}
	}
	
	List<Person> getPersons(){
		Person p1 = new Person("tom","23",101);
		Person p2 = new Person("jerry","32",102);
		Person p3 = new Person("doo","123",103);
		
		List<Person> per = new ArrayList<Person>();
		per.add(p3);
		per.add(p2);
		per.add(p1);

		return per;
	}
}
