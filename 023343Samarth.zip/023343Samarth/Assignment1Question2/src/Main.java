import java.util.Scanner;


public class Main {
	
	static int findPosition(int num,int[] nos){
		int pos = 0;
		for(int i=0; i<nos.length; i++){
			if(nos[i] == num){
				System.out.println("value present at "+i);
				pos = i;
			}
			else
				System.out.println("value is not present");
		}
		return pos;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] num = {10,20,30,40,50};
		Scanner sc = new Scanner(System.in);
		int keyword = sc.nextInt();
		int position = findPosition(keyword, num);
		
	}

}
