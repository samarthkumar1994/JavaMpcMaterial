package com.psl.app;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintWriter;
import java.util.Scanner;

public class FileReadWrite {

	public void copyContent(String inputFile, String outputFile){
		File f1 = new File(inputFile);
		File f2 = new File(outputFile);
		Scanner sc,sc1 = null;
		PrintWriter printer=null;
		if(!f1.exists())
			System.out.println("source file doesnt exist");
		else{
			try {
			//printer = new PrintWriter(f2);
			sc = new Scanner(f1);
			if(f2.exists()){
				System.out.println("Do you want to append existing file(Y/n: )");
				sc1 = new Scanner(System.in);
				String ans = sc1.next();
				if(ans.equalsIgnoreCase("Y")){
					printer = new PrintWriter(new FileOutputStream(f2,true));

					while(sc.hasNext()){
						String content = sc.nextLine();
						System.out.println(content);
						printer.append(content+"\n");
						//System.out.println(1);
					}
				}
				else{
					printer = new PrintWriter(f2);
					while(sc.hasNext()){
						String content = sc.nextLine();
						System.out.println(content);
						printer.write(content+"\n");
						//System.out.println(1);
					}
				}
			}
			else{
				printer = new PrintWriter(f2);
				while(sc.hasNext()){
					String content = sc.nextLine();
					System.out.println(content);
					printer.write(content+"\n");
					//System.out.println(1);
				}
			}
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally{
			//sc.close();
			printer.close();

		}
		}

	}
}
