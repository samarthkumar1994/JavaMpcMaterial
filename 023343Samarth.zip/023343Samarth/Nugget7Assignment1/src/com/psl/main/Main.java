package com.psl.main;

import com.psl.app.FileReadWrite;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String inputFile = args[0];
		String outputFile = args[1];
		FileReadWrite fr = new FileReadWrite();
		fr.copyContent(inputFile, outputFile);
	}

}
