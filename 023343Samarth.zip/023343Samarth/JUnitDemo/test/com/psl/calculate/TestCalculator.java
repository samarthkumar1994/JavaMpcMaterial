package com.psl.calculate;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class TestCalculator {
	Calculator cal = null;
	
	@BeforeClass
	public static void setUpClass(){
		System.out.println("before class");
	}
	
	@Before
	public void setup(){
		System.out.println("@before");
		cal = new Calculator();
	}
	
	@AfterClass
	public static void afterClass(){
		System.out.println("after class");
	}
	
	@After
	public void tearDown(){
		System.out.println("After");
	}
	
	@Test
	public void test_add(){
		int actualResult = cal.add(3, 2);
		int ex = 6;
		Assert.assertEquals(ex,actualResult);
		
	}
	
	@Test
	public void test_mult(){
		Calculator cal = new Calculator();
		int actualResult = cal.mult(3, 2);
		int ex = 6;
		Assert.assertEquals(ex,actualResult);
	}
	
	public void test_divide(){
		Assert.assertEquals(4, cal.divide(4,2));
	}
}
