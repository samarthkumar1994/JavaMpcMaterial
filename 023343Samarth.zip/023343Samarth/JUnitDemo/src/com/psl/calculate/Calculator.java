package com.psl.calculate;

public class Calculator {

	public int add(int x, int y){
		return x*y;
	}
	
	public int mult(int x, int y){
		return x*y;
	}

	// TODO Auto-generated method stub
	public int divide(int x, int y) {
		int result = x/y;
		return result;
	}
}
