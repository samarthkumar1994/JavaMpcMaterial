import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Scanner;


public class ReadLabels {

	public static void main(String[] args) {
		String[] imgName=null;
		Map<String, String> map = new HashMap<String, String>();
		// TODO Auto-generated method stub
		try {
			
			Scanner sc = new Scanner(new File("labels.txt"));
			while(sc.hasNext()){
				
				imgName = sc.next().split(",");
				
				
				
				map.put(imgName[0], imgName[1]);
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		for (Entry<String, String> sam : map.entrySet()) {
			findFile(sam.getKey());
		}
		
	
	}
	 public static void findFile(String name)
	    {
		 	File file=new File("C:/Users/Public/Pictures/Sample Pictures");
	        File[] list = file.listFiles();
	        if(list!=null)
	        for (File fil : list)
	        {
	           
	            if (name.equalsIgnoreCase(fil.getName()))
	            {
	                System.out.println(fil.getParentFile());
	            }
	        }
	    }

}
