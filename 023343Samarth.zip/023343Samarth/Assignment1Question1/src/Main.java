import java.util.Scanner;


public class Main {

	public static String[] initProductNames(){
		
		String[] productList= new String[3];
		productList[0]="sling bag";
		productList[1]="men bag";
		productList[2]="powder";
		return productList;
	}
	
	static boolean isPresent(String[] productNames, String keyword){
		boolean flag = false;
		for(int i =0; i<productNames.length;i++){
			if(productNames[i].contains(keyword)){
			System.out.println(productNames[i]);
				flag=true;
			}
		}
		return flag;
	}
	public static void main(String[] args) {
		String[] pList = null;
		pList = initProductNames();
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the keyword: ");
		String keyword = sc.next();
		boolean res = isPresent(pList, keyword);
	}
}
