/**
 * 
 */

(function ($) {
	 
    $.fn.greenify = function() {
        this.css( {
        	"font-size":"18px",
        	"color":"red"
        } );
        return this;
    };
 
}(jQuery));

(function ($) {
	 
    $.fn.bgcolor = function() {
        this.css( "background-color","grey" );
        return this;
    };
 
}(jQuery));


