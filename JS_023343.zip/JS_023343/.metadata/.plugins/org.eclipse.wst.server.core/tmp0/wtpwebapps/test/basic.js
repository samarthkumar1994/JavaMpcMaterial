document.getElementById("button1").onclick = function(){
alert('event handler 2');
};
