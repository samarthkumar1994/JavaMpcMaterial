//Object Define Property

var pi = {
		use:"math Pi"
		
};

//Object.defineProperty is use to define an existing/new property of an object
//it takes 3 args : 1st arg is obj name
//2nd arg is property name
//3rd arg is one object literal using that you can configure some features of that object properly
Object.defineProperty(pi,"val",{
	value:3.15,
	writable: false,		//not allowed tp update property
	configurable:false,		//if set to true, then we'll be able to delete property
	enumerable:true			//iterable inside
});

//alert(pi.use + pi.val);

//adding property to object using []

/*var usr = {
		name:"Chris",
		site:"www.abc.com"
}

usr["city"] = "nagpur";
var a = "add";
var b = "ress";
usr[a+b] = "Wakad";
alert(usr.address);*/

//Private variable in JS
/*function Employee(n,r){
	this.name = n;
	this.role = r;
	var salary = 40000;				//salary is a private variable
	this.getSalary = function(){
		return salary;
	};
	this.getSalary = function(sal){
		salary = sal;
	};
}

var e1 = new Employee("john","lead");
console.log(e1.name);
var e1sal = e1.getSalary();
console.log(e1sal);
console.log(e1.salary);*/

//Module Pattern in JS
function Employee(n,r){
	this.name = n;
	this.role = r;
}

var e1 = new Employee("John","Lead");
var e2 = new Employee("Emp1","module lead");
var e3 = new Employee("Emp2","Tester");
var e4 = new Employee("Emp3","Developer");

var empModule = (function(){
	var empData = [];
	return{
		addEmp : function(emp){
			empData.push(emp);
		},
		delEmp : function(){
			empData.pop();
		},
		totalEmp : function(){
			return empData.length;
		}
	}
})();

empModule.addEmp(e1);
empModule.addEmp(e2);
empModule.addEmp(e3);
empModule.addEmp(e4);
console.log(empModule.totalEmp());
empModule.delEmp();
console.log(empModule.totalEmp());
