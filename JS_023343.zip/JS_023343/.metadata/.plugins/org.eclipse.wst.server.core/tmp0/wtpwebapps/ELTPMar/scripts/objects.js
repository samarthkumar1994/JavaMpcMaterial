//To create object using JS

var obj = {};	//Empty Object
//Add properties to the created empty object
obj.name = "John";
obj.address = "Pune";

//Read the property
console.log(obj.name);
console.log(obj.address);

//Update the property
obj.name = "Joe";
obj.address = "Dubai";
console.log(obj);

//We can delete properties of an object, not the object itself
delete obj.address;
console.log(obj);
console.log(obj.address);

//other way to create object
var obj1 = new Object();
console.log(obj1);

//Object literal way
var emp1 = {
		name:"Smith",
		company:"persistent",
		role:"Develoepr",
		getEmpDetails:function(){
			console.log("Emp name "+this.name + "company " + this.company);
		}
}
//console.log(emp1);

//Constructor template way to create multiple object of same type. (start with capital letter to indicate it as a constructor)
function Employee(n,r){
	this.name = n;
	this.role = r ;
	this.company = "Persistent";
	this.getEmpDetails =function(){
		console.log("Emp name "+this.name + "role " + this.role);
	}
	
}

var e1 = new Employee("Sam","Dev");
console.log(e1.getEmpDetails());