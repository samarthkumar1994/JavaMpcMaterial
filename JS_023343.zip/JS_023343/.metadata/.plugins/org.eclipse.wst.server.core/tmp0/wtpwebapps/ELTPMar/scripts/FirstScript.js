//alert("Hello from external file JavaScript");
//confirm("Yes or no?");
/*var num1 = parseInt(prompt("Enter 1st number"));
var num2 = parseInt(prompt("2nd number"));
if(isNaN(num1) || isNaN(num2))
	alert("not a num");
alert(num1 * num2);
console.log(num1*num2); 	
*/
/*var res = confirm("yes or no");
alert(res);*/

/*var arr = [];
arr[0] = "1";
arr[1] = "2";
arr[2] = "3";
arr.push("1000")
alert(arr.length);

for(var index in arr){
	alert("array for in :" + arr[index]);
}*/

//8638829160
/*var a = {};
if(a){
	alert(true);
}
else{
	alert(false);
}*/
//only number 0, null, undefined, NaN and empty string returns false. for every other value it's true


