/*function checkIsEmployee(name,isEmp){
	if(isEmp){
		alert(name + "is a Persistent Employee");
	}
	else{
		alert(name + "is on contract");
	}
}

checkIsEmployee("John",false);

//function expression way
var chkEmpSalary = function(){
	alert("Give emp number as inp");
}*/

//function overloading in JS. JS takes only the last function definition.the rest it ignores.. extra params can be accessed with arguments[]

/*function display(){
	alert("Display one");
}

function display(para1){
	alert("Display two" + para1);
}

function display(para1,para2){
	alert("Display three" + para1 + " " + para2);
	alert(arguments[2]);
}

display();
display("paraone","paratwo","parathree","4");*/

//Scope in JS. JS doesn't have block scope

/*var a = "10";
b = "20";
function checkScope(){
	var c = "30";
	d = "40";
	alert(a);
	alert(b);
	alert(c);
	alert(d);
}
checkScope();
alert(a);
alert(b);
alert(c);
alert(d);*/

//IIFE: Immediately Invoked Function Expression

/*var len = 5;
for(var i = 0; i<len;i++){
	alert("In loop" + i);
}*/

(function(){
	var len = 5;
	for(var i = 0; i<len;i++){
		alert("In loop" + i);
	}
}
		)();
alert(i)
