//Question 5
function getRandomizer(bottom, top) {
    return function() {
        return Math.floor( Math.random() * ( 1 + top - bottom ) ) + bottom;
    }
}

var randomNo = getRandomizer( 1, 51 );
var roll = randomNo();
alert(roll);


//Question 1
/*var arr = new Array(1,4,3,4,6,5);
for(var i = 0 ; i < arr.length; i++){
	for(var j = i+1; j<arr.length;j++){
		if(arr[i]==arr[j]){
			alert(arr[i] + " repeated");
		}
	}
	
}*/


//Question 2
/*var arr1 = [1,2,3,4,5];
var arr2 = [4,5,6,7];
var res = arr1.concat(arr2);
console.log(res.sort());
*/

//Question 3
/*
var arr = "My nameasasa is samarth".split(" ");
var len;
var max = arr[0].length;
for( i = 0; i<arr.length; i++){
	if(max < arr[i].length){
		max = arr[i].length;
		len = i;
	}
	
}
console.log(arr[len]);
*/

//Question 4

/*var num = 9;
var cnt = 0;
for(i=0;i<=num;i++){
	if(num%i==0)
		cnt++;
}

if(cnt==2)
	console.log("Prime");
else
	console.log("Not prime");*/