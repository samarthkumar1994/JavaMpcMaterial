//constructor stealing approach
/*function Person(){
	this.city = "Pune";
}

function Employee(){
	Person.call(this);	//steals the constructor
}

var e1 = new Employee();
alert(e1.city);*/

//Prototype chaining approach
function Person(){
	this.city = "Pune";
	this.location = "HJ";
}
Person.prototype.address = "Wakad";

function Employee(){
	this.location = "PT";
}
Employee.prototype = new Person();	//Chaining prototype
//It copies all the properties which is part of parent constructor
//as well as parent prototype
var e1 = new Employee();
console.log(e1.city);
console.log(e1.location);
console.log(e1.address);