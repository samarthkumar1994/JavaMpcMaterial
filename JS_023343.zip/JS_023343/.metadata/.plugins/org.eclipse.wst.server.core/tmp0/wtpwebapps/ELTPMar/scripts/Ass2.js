/*function Person(n,l){
	this.name = n;
	this.location = l;
}

Person.prototype.eat = function(){
	console.log("I like sea food");
}

Person.prototype.introduction = function(){
	console.log("I am " + this.name + "and I live in " + this.location);
}

function Developer(n,l){
	arr = [n,l];
	Person.apply(this,arr);
	this.projects = ["Optum","Cisco"];
}

Developer.prototype = new Person();
Developer.prototype.takeLeave = function(){
	console.log("i am on leave");
}
Developer.prototype.introduction = function(){
	console.log("I am " + this.name + "working at " + this.location + "handling " + this.projects );
}
var p1 = new Developer("sam","Pune");
console.log(p1.name);
console.log(p1.location);
console.log(p1.introduction());*/


function Employee(n,r,id){
	this.name = n;
	this.role = r;
	this.id = id;
}

var e1 = new Employee("John","Lead",1);
var e2 = new Employee("Emp1","module lead",2);
var e3 = new Employee("Emp2","Tester",3);
var e4 = new Employee("Emp3","Developer",4);

var empModule = (function(){
	var empData = [];
	return{
		addEmp : function(emp){
			empData.push(emp);
		},
		delEmp :  function(emp){
			for(i = 0; i<empData.length;i++){
				if(emp.id == empData[i].id)	
					empData.splice(i, 1);
			}
			console.log(empData);
		},
		findEmp : function(emp){
			for(i = 0; i<empData.length;i++){
				if(emp.id == empData[i].id)	
					alert(empData[i]);
			}
		}
	}
})();

empModule.addEmp(e1);
empModule.addEmp(e2);
empModule.addEmp(e3);
empModule.addEmp(e4);
//console.log(empModule.totalEmp());
empModule.delEmp(e2);
//console.log(empModule.totalEmp());

empModule.findEmp(e1);