//create object
var stock = {};
stock.name = "KOTAK";
stock.price = 850;
stock.advice = "Buy";
stock.getStockDetails = function(){
	console.log("Name " + stock.name + " Advice " + stock.advice + " Price " + stock.price);
}
//read props
console.log(stock.getStockDetails());

//update
stock.name = "SBIN";
stock.price = "235";
stock.advice = "BUY";
console.log(stock);

//delete
delete stock.name;
console.log(stock);

//using object literal way
var stock1 = {
		name : "EXCEL",
		price : 41.80,
		advice: "BUY",
		getStockDetails: function(){
			console.log("Name " + this.name + " Advice " + this.advice + " Price " + this.price);
		}
}

console.log(stock1.getStockDetails());

//Constructor template way
function Stock(n,p,a){
	this.name = n;
	this.price = p;
	this.advice = a;
}

Stock.prototype.getStockDetails = function(){
	console.log("Name " + this.name + " Advice " + this.advice + " Price " + this.price);
}

var stock2 = new Stock("SBIN","235","BUY");
var stock3 = new Stock("CBIN","80","SELL");
console.log(stock2);
console.log(stock3);