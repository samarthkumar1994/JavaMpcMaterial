package com.psl.HibernateApp.main;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.psl.HibernateApp.bean.Address;
import com.psl.HibernateApp.bean.Location;
import com.psl.HibernateApp.bean.Student;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Student student1 = new Student();
		student1.setName("samarth");
		student1.setSkills("java");
		Location l1 = new Location("PNQ", "IN");
		Location l2 = new Location("DEL", "IN");
		Address a1 = new Address(1, "D", "HJ",l1);
		Address a2 = new Address(2, "A", "kondhwa",l2);
		student1.getAdd().add(a1);
		student1.getAdd().add(a2);
		//System.out.println(student1.getAdd().toString());
		/*Student stud2=new Student();
		stud2.setName("suraj");
		stud2.setSkills("c++");*/
		/*List<Student> studList = new ArrayList<Student>();
		Student stud3 = new Student(3, "Jyoti", "nothing");
		Student stud4 = new Student(4,"aakash","c++");
		Student stud5 = new Student(5, "abc","sql");
		
		studList.add(stud3);
		studList.add(stud4);
		studList.add(stud5);*/
		
		SessionFactory sessionfactory = new Configuration().configure().buildSessionFactory();
		Session session = sessionfactory.openSession();
		session.beginTransaction();
		/*session.save(student1);
		session.save(stud2);*/
		/*for (Student student : studList) {
			session.save(student);
		}*/
		//Student student = (Student)session.get(Student.class, 2);		//to fetch records. arg2 is primary key
		//session.delete(student);  		//to delete record
		//student.setSkills(".net");
		//session.update(student);			//to update record
		session.save(student1);

		session.getTransaction().commit();
		session.close();
		//System.out.println("--------"+student.getName()+"-------");
	}

}
