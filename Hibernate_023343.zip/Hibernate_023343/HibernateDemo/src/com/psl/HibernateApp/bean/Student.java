package com.psl.HibernateApp.bean;

import java.util.Collection;
import java.util.HashSet;

import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="student_details")
public class Student {
	@Id
	@Column(name="student_id")		//to set an alternate name for the table to be created
	@GeneratedValue(strategy=GenerationType.IDENTITY)	//to auto generate primary key values. AUTO generates sequence
	private int id;
	@Column(name="student_name")
	private String name;
	@Column(name="student_skills")
	private String skills;
	
	/*@Embedded
	private Address officialAddress;
	
	@Embedded
	@AttributeOverrides(value = { 
			@AttributeOverride(name = "flatNo",column = @Column(name="home_flatNo")),
			@AttributeOverride( name = "building", column = @Column(name="home_building")),
			@AttributeOverride(name = "area",column = @Column(name="home_area")),
			@AttributeOverride( name = "city",column = @Column(name="home_city")),
			@AttributeOverride(name = "country",column = @Column(name="home_country"))
	})
	private Address homeAddress;
	
	public Address getOfficialAddress() {
		return officialAddress;
	}
	public void setOfficialAddress(Address officialAddress) {
		this.officialAddress = officialAddress;
	}*/
	@ElementCollection(fetch=FetchType.EAGER)
	Collection<Address> add = new HashSet<Address>();
	
	public Collection<Address> getAdd() {
		return add;
	}
	public void setAdd(Collection<Address> add) {
		this.add = add;
	}
	public Student(int id, String name, String skills) {
		super();
		this.id = id;
		this.name = name;
		this.skills = skills;
	}
	public Student() {
		super();
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getSkills() {
		return skills;
	}
	public void setSkills(String skills) {
		this.skills = skills;
	}
	
	
	
}
