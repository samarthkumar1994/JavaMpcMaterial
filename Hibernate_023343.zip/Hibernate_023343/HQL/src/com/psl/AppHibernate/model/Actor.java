package com.psl.AppHibernate.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedNativeQuery;
import javax.persistence.Table;

@Entity
@Table(name="actor_details")
@NamedNativeQuery(name = "", query = "")

public class Actor implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="actor_id")
	private int actor_id;
	
	@Column(name="actor_name")
	private String name;
	
	@Column(name="actor_money")
	private double money;
	
	@Column(name="actor_industry")
	private String industry;

	public Actor() {
		super();
	}
	
	public Actor(int actor_id, String name, double money, String industry) {
		super();
		this.actor_id = actor_id;
		this.name = name;
		this.money = money;
		this.industry = industry;
	}

	public int getActor_id() {
		return actor_id;
	}

	public void setActor_id(int actor_id) {
		this.actor_id = actor_id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getMoney() {
		return money;
	}

	public void setMoney(double money) {
		this.money = money;
	}

	public String getIndustry() {
		return industry;
	}

	public void setIndustry(String industry) {
		this.industry = industry;
	}
	
	
}
