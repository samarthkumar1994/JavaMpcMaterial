package com.psl.AppHibernate.main;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.psl.AppHibernate.model.Actor;

public class Main {
	
	public static void main(String[] args){
		List<Actor> actList = populate();
				
		SessionFactory sessionfactory = new Configuration().configure().buildSessionFactory();
		Session session = sessionfactory.openSession();
		session.beginTransaction();
		
			session.createNativeQuery("select * from actor_details", Actor.class);
			/*for(Actor actor:actList){
				session.save(actor);
			}*/
		session.getTransaction().commit();
		session.close();
	}

	public static List<Actor> populate(){
		
		List<Actor> list = new ArrayList<Actor>();
		
		Actor act1 = new Actor();
		act1.setName("Tom");
		act1.setMoney(200000);
		act1.setIndustry("hollywood");
		
		Actor act2 = new Actor();
		act2.setName("Dick");
		act2.setMoney(500000);
		act2.setIndustry("bollywood");
		
		Actor act3 = new Actor();
		act3.setName("Harry");
		act3.setMoney(100000);
		act3.setIndustry("hollywood");
		
		Actor act4 = new Actor();
		act4.setName("Patel");
		act4.setMoney(52631);
		act4.setIndustry("bollywood");
		
		list.add(act1);
		list.add(act2);
		list.add(act3);
		list.add(act4);
		
		return list;
	}
}

