package com.psl.HibernateApp.bean;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.DiscriminatorColumn;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.Table;

@Entity
@Table(name="person_details")
/*@DiscriminatorColumn(name="category")
@DiscriminatorValue(value = "base_person")*/
@Inheritance(strategy=InheritanceType.TABLE_PER_CLASS)
public class Person implements Serializable{
	@Id
	@GeneratedValue(strategy=GenerationType.TABLE)	//to auto generate primary key values. AUTO generates sequence
	private int id;
	
	@Column(name="person_name")
	private String name;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Person(int id, String name) {
		super();
		this.id = id;
		this.name = name;
	}

	public Person() {
		super();
	}
	
	
}
