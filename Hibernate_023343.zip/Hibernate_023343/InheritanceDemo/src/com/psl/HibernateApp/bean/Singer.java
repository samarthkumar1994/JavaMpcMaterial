package com.psl.HibernateApp.bean;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name="singer_details")
public class Singer extends Person implements Serializable{
	@Column(name="expertise_details")
	private String expertise;

	public String getExpertise() {
		return expertise;
	}

	public void setExpertise(String expertise) {
		this.expertise = expertise;
	}
	
	
	
}
