package com.psl.HibernateApp.main;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.psl.HibernateApp.bean.Person;
import com.psl.HibernateApp.bean.Politician;
import com.psl.HibernateApp.bean.Singer;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	Person person1 = new Person();
	Person person2 = new Person();
	person1.setName("Trump");
	person2.setName("Anand");
	
	Singer singer1 = new Singer();
	Singer singer2 = new Singer();
	singer1.setName("Sonu"); singer1.setExpertise("All");
	singer2.setName("Lata"); singer2.setExpertise("Classical");
	
	Politician p1 = new Politician();
	Politician p2 = new Politician();
	p1.setName("Modi"); p1.setDesignation("PM");
	p2.setName("Yogi"); p2.setDesignation("CM");
		
		SessionFactory sessionfactory = new Configuration().configure().buildSessionFactory();
		Session session = sessionfactory.openSession();
		session.beginTransaction();
			session.save(person1);
			session.save(person2);
			session.save(p1);
			session.save(p2);
			session.save(singer1);
			session.save(singer2);
		session.getTransaction().commit();
		session.close();
		//System.out.println("--------"+student.getName()+"-------");
	}

}
