package com.psl.HibernateApp.main;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.psl.HibernateApp.bean.Address;
import com.psl.HibernateApp.bean.Location;
import com.psl.HibernateApp.bean.Skill;
import com.psl.HibernateApp.bean.Student;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Student student1 = new Student();
		Student student2 = new Student();
		Student student3 = new Student();
		
		Skill skill1 = new Skill();
		Skill skill2 = new Skill();
		Skill skill3 = new Skill();
		
		skill1.setName("java");
		skill2.setName("javascript");
		skill3.setName("hibernate");
		skill1.setVersion(8);
		skill2.setVersion(3);
		skill3.setVersion(5.2);
		
		student1.setName("Ashwin");
		student2.setName("sam");
		student3.setName("suraj");
		
		/*skill1.setStudent(student1);
		skill2.setStudent(student1);*/
		
	/*	skill1.getStudents().add(student1);
		skill1.getStudents().add(student2);
		skill2.getStudents().add(student1);
		skill2.getStudents().add(student2);
		skill2.getStudents().add(student3);
		skill1.getStudents().add(student3);*/
		
		student1.getSkills().add(skill1);
		student1.getSkills().add(skill2);
		student2.getSkills().add(skill2);
		student2.getSkills().add(skill1);
		student3.getSkills().add(skill1);
		
		SessionFactory sessionfactory = new Configuration().configure().buildSessionFactory();
		Session session = sessionfactory.openSession();
		session.beginTransaction();
		
		session.save(student1);
		session.save(student2);
		session.save(student3);
		session.save(skill1);
		session.save(skill2);
		session.save(skill3);

		session.getTransaction().commit();
		session.close();
		//System.out.println("--------"+student.getName()+"-------");
	}

}
