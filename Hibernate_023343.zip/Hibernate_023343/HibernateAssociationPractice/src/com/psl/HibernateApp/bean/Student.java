package com.psl.HibernateApp.bean;

import java.io.Serializable;
import java.util.Collection;
import java.util.HashSet;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

import org.hibernate.annotations.CollectionId;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Type;

@Entity
@Table(name="student_details")
public class Student implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
	@Column(name="student_id")		//to set an alternate name for the table to be created
	@GeneratedValue(strategy=GenerationType.IDENTITY)	//to auto generate primary key values. AUTO generates sequence
	private int id;
	@Column(name="student_name")
	private String name;

	/*@OneToOne
	private Skill skill;			//make an entity skill.
	*/
	/*@OneToMany*/
	@ManyToMany
	//below 2 annotations are used to generate primary key for studentSkills
	@GenericGenerator(name="sequenceGen", strategy="hilo")
	@CollectionId(columns={@Column(name="studentskill_id") }, generator="sequenceGen", type=@Type(type="int"))
	@JoinTable(name="studentSkills",joinColumns=@JoinColumn(name="studentId"),
	inverseJoinColumns=@JoinColumn(name="skillId"))
	private Collection<Skill> skills = new HashSet<Skill>();

	public Student() {
		super();
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Student(int id, String name) {
		super();
		this.id = id;
		this.name = name;
	}
	public Collection<Skill> getSkills() {
		return skills;
	}
	public void setSkills(Collection<Skill> skills) {
		this.skills = skills;
	}
	
	
	
	
}
