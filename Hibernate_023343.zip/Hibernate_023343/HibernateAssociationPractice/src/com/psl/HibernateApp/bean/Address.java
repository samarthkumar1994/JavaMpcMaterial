package com.psl.HibernateApp.bean;

import javax.persistence.Embeddable;
import javax.persistence.Embedded;

@Embeddable
public class Address {
	
	private int flatNo;
	private String building;
	private String area;
	
	@Embedded
	private Location location;
	
	public Address(int flatNo, String building, String area, Location location) {
		super();
		this.flatNo = flatNo;
		this.building = building;
		this.area = area;
		this.location = location;
	}
	public Address() {
		super();
	}
	public int getFlatNo() {
		return flatNo;
	}
	public void setFlatNo(int flatNo) {
		this.flatNo = flatNo;
	}
	public String getBuilding() {
		return building;
	}
	public void setBuilding(String building) {
		this.building = building;
	}
	public String getArea() {
		return area;
	}
	public void setArea(String area) {
		this.area = area;
	}
	public Location getLocation() {
		return location;
	}
	public void setLocation(Location location) {
		this.location = location;
	}
	
	
}
