package com.psl.HibernateApp.bean;

import java.util.Collection;
import java.util.HashSet;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="skill_details")
public class Skill {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="skill_id")
	private int skillId;
	
	@Column(name="skill_name")
	private String name;
	
	@Column(name="skill_version")
	private double version;
	
/*	@ManyToMany(cascade = CascadeType.ALL,mappedBy="skills")
	private Collection<Student> students = new HashSet<Student>();*/
	
	@ManyToOne
	private Student student;

	public int getSkillId() {
		return skillId;
	}

	public void setSkillId(int skillId) {
		this.skillId = skillId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getVersion() {
		return version;
	}

	public void setVersion(double version) {
		this.version = version;
	}

	public Skill(int skillId, String name, double version) {
		super();
		this.skillId = skillId;
		this.name = name;
		this.version = version;
	}

	public Skill() {
		super();
	}

	public Student getStudent() {
		return student;
	}

	public void setStudent(Student student) {
		this.student = student;
	}

/*	public Collection<Student> getStudents() {
		return students;
	}

	public void setStudents(Collection<Student> students) {
		this.students = students;
	}
*/
	
}
