package com.psl.HibernateApp.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="skill_details")
public class Skill {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="skill_id")
	private int skillId;
	
	@Column(name="skill_name")
	private String name;
	
	@Column(name="skill_version")
	private double version;

	public int getSkillId() {
		return skillId;
	}

	public void setSkillId(int skillId) {
		this.skillId = skillId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getVersion() {
		return version;
	}

	public void setVersion(double version) {
		this.version = version;
	}

	public Skill(int skillId, String name, double version) {
		super();
		this.skillId = skillId;
		this.name = name;
		this.version = version;
	}

	public Skill() {
		super();
	}
	
	
}
