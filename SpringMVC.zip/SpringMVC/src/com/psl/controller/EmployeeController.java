package com.psl.controller;

import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.psl.entity.Employee;

@Controller
//@RequestMapping(value="/emp")			//the url will become http://localhost:8080/SpringMVC/emp/home
public class EmployeeController {

	@RequestMapping(value={"/","/home"}, method=RequestMethod.GET)	
	public String showHomePage(Model model){
			System.out.println("Inside employee controller.showhomepage");
			model.addAttribute("employee",new Employee());
			return "home";
		}
	
	@RequestMapping(value={"/","/home"}, method=RequestMethod.POST)	
	public String register(Model model, @Valid Employee e, BindingResult result){
			System.out.println("Inside employee controller.register " + e.getName());
			//model.addAttribute("employee",new Employee());
			if(result.hasErrors())
				return "home";
			
			return "home";
		}
	
	@RequestMapping(value="/{empName}", method=RequestMethod.GET)	
	public String showEmpPage(Model model, @PathVariable String empName, @RequestParam(required=false) String addr){
			System.out.println("Inside employee controller.showEmppage");
			model.addAttribute("empName", empName);
			model.addAttribute("city", addr);
			return "emp";
		}
	

}
